<?php
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="participants_' . date('Y-m-d_H-i-s') . '.csv"');

require_once 'view_logs.php';

$participants = getParticipants();

if ($participants === false || count($participants) === 0) {
    echo "Нет данных для выгрузки.";
    exit;
}

$output = fopen('php://output', 'w');

// Заголовки столбцов
$headers = [
    '📋 Код регистрации',
    '📅 Дата регистрации',
    '👤 ФИО',
    '🎂 Дата рождения',
    '🏙️ Город',
    '📞 Телефон',
    '📧 Email',
    '👶 Дети',
    '🏄 Кол-во SUP',
    '💰 Стоимость SUP',
    '💳 Статус оплаты',
    '🆔 ID пользователя',
    '⏰ Timestamp'
];

fputcsv($output, $headers);

foreach ($participants as $p) {
    $fio = trim($p['surname'] . ' ' . $p['name'] . ' ' . $p['patronymic']);
    $row = [
        $p['code'],
        $p['date'],
        $fio,
        $p['birthdate'],
        $p['city'],
        $p['phone'],
        $p['email'],
        $p['children'],
        $p['sup_count'],
        $p['sup_cost'],
        $p['payment_status'],
        $p['user_id'],
        $p['timestamp']
    ];
    fputcsv($output, $row);
}

fclose($output);
exit;
?>
