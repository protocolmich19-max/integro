#!/bin/bash

# Переход в директорию сайта
cd /var/www/event.sup31.ru

# Установка Composer локально
echo "Установка Composer..."
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php composer-setup.php
php -r "unlink('composer-setup.php');"

# Установка PHPWord
echo "Установка PHPWord..."
php composer.phar require phpoffice/phpword

# Установка прав доступа
chmod -R 755 vendor/

echo "Установка завершена!"
echo "PHPWord установлен в /var/www/event.sup31.ru/vendor/"
