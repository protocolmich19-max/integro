<?php
header('Content-Type: text/html; charset=utf-8');

// Настройки
$log_file = 'google_sheets_log.txt';
$lines_to_show = 100;
$spreadsheet_id = '1KrCPs620PGaFXRWqrkqwvZGD_G9L5K91Ct74gVq6pqs';
$sheet_name = 'Регистрация';
$service_account_file = 'service-account.json';

// Обработка действий с логами
if (isset($_GET['action'])) {
    if ($_GET['action'] === 'download' && file_exists($log_file)) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="logs_' . date('Y-m-d_H-i-s') . '.txt"');
        readfile($log_file);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'clear') {
    if (file_exists($log_file)) {
        file_put_contents($log_file, '');
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Функции для работы с Google Sheets
function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function getAccessToken() {
    global $service_account_file;
    
    if (!file_exists($service_account_file)) {
        return false;
    }

    $credentials = json_decode(file_get_contents($service_account_file), true);
    if (!$credentials) {
        return false;
    }

    $jwt_header = base64url_encode(json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]));
    
    $now = time();
    $jwt_payload = base64url_encode(json_encode([
        'iss' => $credentials['client_email'],
        'scope' => 'https://www.googleapis.com/auth/spreadsheets.readonly',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600
    ]));
    
    $jwt_signing_input = $jwt_header . '.' . $jwt_payload;
    
    $private_key = openssl_pkey_get_private($credentials['private_key']);
    if (!$private_key) {
        return false;
    }
    
    openssl_sign($jwt_signing_input, $signature, $private_key, OPENSSL_ALGO_SHA256);
    $jwt = $jwt_signing_input . '.' . base64url_encode($signature);
    
    $token_request = [
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ];
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($token_request),
            'ignore_errors' => true
        ]
    ]);
    
    $response = @file_get_contents('https://oauth2.googleapis.com/token', false, $context);
    
    if ($response === false) {
        return false;
    }
    
    $token_data = json_decode($response, true);
    
    return isset($token_data['access_token']) ? $token_data['access_token'] : false;
}

function getParticipants() {
    global $spreadsheet_id, $sheet_name;
    
    $access_token = getAccessToken();
    if (!$access_token) {
        error_log("[ERROR] Не удалось получить токен доступа");
        return false;
    }
    
    $range = $sheet_name . '!A:O';
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}";
    
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ],
            'ignore_errors' => true
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        error_log("[ERROR] Не удалось получить данные из Google Sheets");
        return false;
    }
    
    $data = json_decode($response, true);
    
    if (!isset($data['values']) || count($data['values']) < 2) {
        return [];
    }
    
    // Пропускаем заголовок
    $participants = [];
    for ($i = 1; $i < count($data['values']); $i++) {
        $row = $data['values'][$i];
        // Обрабатываем строку даже если не все поля заполнены
        $participants[] = [
            'code' => isset($row[0]) ? $row[0] : '',
            'date' => isset($row[1]) ? $row[1] : '',
            'surname' => isset($row[2]) ? $row[2] : '',
            'name' => isset($row[3]) ? $row[3] : '',
            'patronymic' => isset($row[4]) ? $row[4] : '',
            'birthdate' => isset($row[5]) ? $row[5] : '',
            'city' => isset($row[6]) ? $row[6] : '',
            'phone' => isset($row[7]) ? $row[7] : '',
            'email' => isset($row[8]) ? $row[8] : '',
            'children' => isset($row[9]) ? $row[9] : '',
            'sup_count' => isset($row[10]) ? intval($row[10]) : 0,
            'sup_cost' => isset($row[11]) ? intval($row[11]) : 0,
            'payment_status' => isset($row[12]) ? $row[12] : '',
            'user_id' => isset($row[13]) ? $row[13] : '',
            'timestamp' => isset($row[14]) ? $row[14] : ''
        ];
    }
    
    return array_reverse($participants); // Последние сверху
}

// Получаем данные участников
$participants = getParticipants();

?>
<script>
// Переключение вкладок
function switchTab(tabName) {
    // Убираем активный класс со всех вкладок
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Добавляем активный класс нужной вкладке
    // Находим вкладку по содержимому
    document.querySelectorAll('.tab').forEach(tab => {
        if ((tabName === 'participants' && tab.textContent.includes('Участники')) ||
            (tabName === 'logs' && tab.textContent.includes('Системные логи'))) {
            tab.classList.add('active');
        }
    });
    
    document.getElementById(tabName).classList.add('active');
    
    // Управление автообновлением
    if (tabName === 'logs') {
        startAutoRefresh();
    } else {
        stopAutoRefresh();
    }
}

// Поиск участников
function searchParticipants() {
    const input = document.getElementById('searchInput');
    const filter = input.value.toLowerCase();
    const table = document.getElementById('participantsTable');
    if (!table) return;
    
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const text = row.textContent.toLowerCase();
        
        if (text.includes(filter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    }
}

// Экспорт в Excel
function exportToExcel() {
    // Проверяем, есть ли файл export_excel.php
    fetch('export_excel.php', {method: 'HEAD'})
        .then(response => {
            if (response.ok) {
                window.location.href = 'export_excel.php';
            } else {
                alert('Файл для экспорта в Excel не найден (export_excel.php)');
            }
        })
        .catch(error => {
            console.error('Ошибка при экспорте в Excel:', error);
            alert('Ошибка при экспорте в Excel. Проверьте консоль для подробностей.');
        });
}

// Экспорт соглашений
function exportAgreements() {
    // Проверяем, есть ли файл export_agreements_docx.php
    fetch('export_agreements_docx.php', {method: 'HEAD'})
        .then(response => {
            if (response.ok) {
                window.location.href = 'export_agreements_docx.php';
            } else {
                alert('Файл для экспорта соглашений не найден (export_agreements_docx.php)');
            }
        })
        .catch(error => {
            console.error('Ошибка при экспорте соглашений:', error);
            alert('Ошибка при экспорте соглашений. Проверьте консоль для подробностей.');
        });
}

// Функции для логов
function clearLogs() {
    if (confirm('Вы уверены, что хотите очистить все логи?')) {
        fetch('?action=clear', {method: 'POST'})
            .then(response => {
                if (response.ok) {
                    location.reload();
                } else {
                    alert('Ошибка при очистке логов');
                }
            })
            .catch(error => {
                console.error('Ошибка при очистке логов:', error);
                alert('Ошибка при очистке логов');
            });
    }
}

function downloadLogs() {
    window.location.href = '?action=download';
}

// Автообновление для вкладки логов
let refreshInterval;

function startAutoRefresh() {
    // Останавливаем предыдущий интервал, если он есть
    stopAutoRefresh();
    
    refreshInterval = setInterval(() => {
        if (!document.hidden && document.getElementById('logs').classList.contains('active')) {
            location.reload();
        }
    }, 10000); // 10 секунд
}

function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Если открыта вкладка логов, запускаем автообновление
    if (document.getElementById('logs') && document.getElementById('logs').classList.contains('active')) {
        startAutoRefresh();
    }
    
    // Добавляем обработчики для вкладок
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            if (this.textContent.includes('Системные логи')) {
                startAutoRefresh();
            } else {
                stopAutoRefresh();
            }
        });
    });
});

// Останавливаем автообновление при уходе со страницы
window.addEventListener('beforeunload', function() {
    stopAutoRefresh();
});

</script>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления - САПОТВОРЕНИЕ</title>
	<link rel="icon" href="data:,"> <!-- Фикс для ошибки favicon -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            color: #333;
        }
        
        .container {
            max-width: 100%;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            color: white;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .tabs-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }
        
        .tabs {
            display: flex;
            background: #f8f9fa;
            border-bottom: 2px solid #e9ecef;
        }
        
        .tab {
            flex: 1;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            font-weight: 600;
            color: #6c757d;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .tab:hover {
            background: #e9ecef;
        }
        
        .tab.active {
            color: #0891b2;
            background: white;
        }
        
        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            right: 0;
            height: 2px;
            background: #0891b2;
        }
        
        .tab-content {
            display: none;
            padding: 30px;
            animation: fadeIn 0.3s ease;
        }
        
        .tab-content.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Стили для участников */
        .participants-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .participants-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            flex: 1;
            min-width: 200px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card.green {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        }
        
        .stat-card.blue {
            background: linear-gradient(135deg, #2193b0 0%, #6dd5ed 100%);
        }
        
        .stat-card.orange {
            background: linear-gradient(135deg, #f2994a 0%, #f2c94c 100%);
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .participants-table-container {
            background: #f8f9fa;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .table-wrapper {
            overflow-x: auto;
            max-height: 70vh;
            overflow-y: auto;
        }
        
        .participants-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1600px;
        }
        
        .participants-table th {
            background: #e9ecef;
            padding: 15px 12px;
            text-align: left;
            font-weight: 600;
            color: #495057;
            font-size: 0.9rem;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .participants-table td {
            padding: 15px 12px;
            border-bottom: 1px solid #dee2e6;
            color: #495057;
            font-size: 0.9rem;
            max-width: 200px;
            word-wrap: break-word;
            vertical-align: top;
        }
        
        .participants-table tr:hover {
            background: #f1f3f5;
        }
        
        /* Ширины колонок */
        .participants-table th:nth-child(1), .participants-table td:nth-child(1) { width: 140px; min-width: 140px; }
        .participants-table th:nth-child(2), .participants-table td:nth-child(2) { width: 130px; min-width: 130px; }
        .participants-table th:nth-child(3), .participants-table td:nth-child(3) { width: 200px; min-width: 200px; }
        .participants-table th:nth-child(4), .participants-table td:nth-child(4) { width: 110px; min-width: 110px; }
        .participants-table th:nth-child(5), .participants-table td:nth-child(5) { width: 120px; min-width: 120px; }
        .participants-table th:nth-child(6), .participants-table td:nth-child(6) { width: 130px; min-width: 130px; }
        .participants-table th:nth-child(7), .participants-table td:nth-child(7) { width: 200px; min-width: 200px; }
        .participants-table th:nth-child(8), .participants-table td:nth-child(8) { width: 180px; min-width: 180px; }
        .participants-table th:nth-child(9), .participants-table td:nth-child(9) { width: 80px; min-width: 80px; }
        .participants-table th:nth-child(10), .participants-table td:nth-child(10) { width: 100px; min-width: 100px; }
        .participants-table th:nth-child(11), .participants-table td:nth-child(11) { width: 140px; min-width: 140px; }
        .participants-table th:nth-child(12), .participants-table td:nth-child(12) { width: 120px; min-width: 120px; }
        .participants-table th:nth-child(13), .participants-table td:nth-child(13) { width: 100px; min-width: 100px; }
        
        .participant-name {
            font-weight: 600;
            color: #212529;
            line-height: 1.3;
        }
        
        .participant-code {
            font-family: monospace;
            background: #e3f2fd;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            color: #1565c0;
            font-weight: 600;
        }
        
        .children-badge {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            display: inline-block;
            font-weight: 600;
        }
        
        .sup-badge {
            background: #fff3e0;
            color: #e65100;
            padding: 6px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
            text-align: center;
        }
        
        .payment-status {
            padding: 6px 12px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
            text-align: center;
            white-space: nowrap;
        }
        
        .payment-status.paid {
            background: #d4edda;
            color: #155724;
        }
        
        .payment-status.pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .payment-status.free {
            background: #cce5ff;
            color: #004085;
        }
        
        .no-data {
            text-align: center;
            padding: 60px;
            color: #6c757d;
        }
        
        .no-data img {
            width: 100px;
            opacity: 0.3;
            margin-bottom: 20px;
        }
        
        /* Стили для логов */
        .controls {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            background: #0891b2;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }
        
        .btn:hover {
            background: #0e7490;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(8, 145, 178, 0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .log-container {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 12px;
            padding: 20px;
            max-height: 600px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
        }
        
        .log-line {
            padding: 8px 12px;
            margin-bottom: 4px;
            border-radius: 6px;
            word-break: break-all;
        }
        
        .log-line.info {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .log-line.success {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .log-line.warning {
            background: #fff3e0;
            color: #e65100;
        }
        
        .log-line.error {
            background: #ffebee;
            color: #c62828;
        }
        
        .log-line.debug {
            background: #f3e5f5;
            color: #6a1b9a;
            font-size: 0.85rem;
        }
        
        .timestamp {
            color: #6c757d;
            font-weight: 600;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-item {
            background: white;
            border: 1px solid #dee2e6;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        
        /* Поиск */
        .search-box {
            position: relative;
            max-width: 300px;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 45px 12px 15px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: #0891b2;
            box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.1);
        }
        
        .search-box .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .controls-section {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.8rem;
            }
            
            .participants-stats {
                flex-direction: column;
            }
            
            .participants-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .controls-section {
                justify-content: center;
            }
            
            .search-box {
                max-width: 100%;
            }
            
            .btn {
                padding: 10px 16px;
                font-size: 13px;
            }
        }
        
        /* Scrollbar для таблицы */
        .table-wrapper::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        .table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        .table-wrapper::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }
        
        .table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏄‍♀️ Панель управления САПОТВОРЕНИЕ</h1>
            <p>Фестиваль на SUP-досках • 13 июля 2025</p>
        </div>
        
        <div class="tabs-container">
            <div class="tabs">
                <div class="tab active" onclick="switchTab('participants')">
                    👥 Участники
                </div>
                <div class="tab" onclick="switchTab('logs')">
                    📋 Системные логи
                </div>
            </div>
            
            <!-- Вкладка участников -->
            <div id="participants" class="tab-content active">
                <div class="participants-header">
                    <h2>Зарегистрированные участники</h2>
                    <div class="controls-section">
                        <div class="search-box">
                            <input type="text" id="searchInput" placeholder="Поиск участников..." onkeyup="searchParticipants()">
                            <span class="search-icon">🔍</span>
                        </div>
                        <button class="btn" onclick="exportToExcel()">📊 Выгрузить в Excel</button>
                        <button class="btn btn-secondary" onclick="exportAgreements()">📄 Выгрузить соглашения</button>
                    </div>
                </div>
                
                <?php if ($participants !== false && count($participants) > 0): ?>
                    <?php
                    // Подсчет статистики
                    $total_participants = count($participants);
                    $total_children = 0;
                    $total_sups = 0;
                    $total_revenue = 0;
                    
                    foreach ($participants as $p) {
                        if (!empty($p['children'])) {
                            $total_children += substr_count($p['children'], ',') + 1;
                        }
                        $total_sups += intval($p['sup_count']);
                        $total_revenue += intval($p['sup_cost']);
                    }
                    ?>
                    
                    <div class="participants-stats">
                        <div class="stat-card">
                            <div class="stat-value"><?php echo $total_participants; ?></div>
                            <div class="stat-label">Всего участников</div>
                        </div>
                        <div class="stat-card green">
                            <div class="stat-value"><?php echo $total_children; ?></div>
                            <div class="stat-label">Детей</div>
                        </div>
                        <div class="stat-card blue">
                            <div class="stat-value"><?php echo $total_sups; ?></div>
                            <div class="stat-label">SUP в аренде</div>
                        </div>
                        <div class="stat-card orange">
                            <div class="stat-value"><?php echo number_format($total_revenue, 0, '', ' '); ?>₽</div>
                            <div class="stat-label">Ожидаемый доход</div>
                        </div>
                    </div>
                    
                    <div class="participants-table-container">
                        <div class="table-wrapper">
                            <table class="participants-table" id="participantsTable">
                                <thead>
                                    <tr>
                                        <th>📋 Код</th>
                                        <th>📅 Дата</th>
                                        <th>👤 ФИО</th>
                                        <th>🎂 Рождение</th>
                                        <th>🏙️ Город</th>
                                        <th>📞 Телефон</th>
                                        <th>📧 Email</th>
                                        <th>👶 Дети</th>
                                        <th>🏄 SUP</th>
                                        <th>💰 Сумма</th>
                                        <th>💳 Оплата</th>
                                        <th>🆔 User ID</th>
                                        <th>⏰ Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($participants as $p): ?>
                                        <tr>
                                            <td><span class="participant-code"><?php echo htmlspecialchars($p['code']); ?></span></td>
                                            <td><?php echo htmlspecialchars($p['date']); ?></td>
                                            <td class="participant-name">
                                                <?php 
                                                $fio = trim($p['surname'] . ' ' . $p['name'] . ' ' . $p['patronymic']);
                                                echo htmlspecialchars($fio ?: '-'); 
                                                ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($p['birthdate'] ?: '-'); ?></td>
                                            <td><?php echo htmlspecialchars($p['city'] ?: '-'); ?></td>
                                            <td><?php echo htmlspecialchars($p['phone'] ?: '-'); ?></td>
                                            <td style="word-break: break-all;"><?php echo htmlspecialchars($p['email'] ?: '-'); ?></td>
                                            <td>
                                                <?php if (!empty($p['children'])): ?>
                                                    <span class="children-badge" title="<?php echo htmlspecialchars($p['children']); ?>">
                                                        <?php 
                                                        $children_count = substr_count($p['children'], ',') + 1;
                                                        echo $children_count . ' ' . ($children_count == 1 ? 'ребёнок' : 'детей'); 
                                                        ?>
                                                    </span>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($p['sup_count'] > 0): ?>
                                                    <span class="sup-badge"><?php echo $p['sup_count']; ?> шт.</span>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($p['sup_cost'] > 0): ?>
                                                    <strong><?php echo number_format($p['sup_cost'], 0, '', ' '); ?>₽</strong>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                $status_class = 'free';
                                                $status_text = 'Не требуется';
                                                
                                                if ($p['sup_cost'] > 0) {
                                                    if ($p['payment_status'] === 'Оплачено') {
                                                        $status_class = 'paid';
                                                        $status_text = '✅ Оплачено';
                                                    } else {
                                                        $status_class = 'pending';
                                                        $status_text = '⏳ Ожидает';
                                                    }
                                                }
                                                ?>
                                                <span class="payment-status <?php echo $status_class; ?>">
                                                    <?php echo $status_text; ?>
                                                </span>
                                            </td>
                                            <td><small style="font-family: monospace;"><?php echo htmlspecialchars(substr($p['user_id'] ?: '-', 0, 12) . '...'); ?></small></td>
                                            <td><small><?php echo htmlspecialchars($p['timestamp'] ? date('d.m H:i', $p['timestamp']) : '-'); ?></small></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <p style="font-size: 1.2rem;">Пока нет зарегистрированных участников</p>
                        <p style="color: #6c757d;">Данные появятся после первой регистрации</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Вкладка логов -->
            <div id="logs" class="tab-content">
                <h2 style="margin-bottom: 20px;">Системные логи</h2>
                
                <div class="controls">
                    <button class="btn" onclick="location.reload()">🔄 Обновить</button>
                    <button class="btn btn-secondary" onclick="clearLogs()">🗑️ Очистить логи</button>
                    <button class="btn btn-secondary" onclick="downloadLogs()">💾 Скачать логи</button>
                    <a href="test_sheets.php" class="btn">🧪 Тест подключения</a>
                    <a href="index.html" class="btn">🏠 На главную</a>
                </div>
                
                <?php
                if (file_exists($log_file)) {
                    $filesize = filesize($log_file);
                    $logs = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                    $total_lines = count($logs);
                    
                    // Подсчет статистики
                    $stats = [
                        'total' => $total_lines,
                        'success' => 0,
                        'error' => 0,
                        'warning' => 0
                    ];
                    
                    foreach ($logs as $log) {
                        if (strpos($log, '[SUCCESS]') !== false) $stats['success']++;
                        elseif (strpos($log, '[ERROR]') !== false) $stats['error']++;
                        elseif (strpos($log, '[WARNING]') !== false) $stats['warning']++;
                    }
                    ?>
                    
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-label">Всего записей</div>
                            <div class="stat-value"><?php echo $stats['total']; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Успешных</div>
                            <div class="stat-value" style="color: #2e7d32;"><?php echo $stats['success']; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Ошибок</div>
                            <div class="stat-value" style="color: #c62828;"><?php echo $stats['error']; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Предупреждений</div>
                            <div class="stat-value" style="color: #e65100;"><?php echo $stats['warning']; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Размер файла</div>
                            <div class="stat-value"><?php echo round($filesize / 1024, 2); ?> KB</div>
                        </div>
                    </div>
                    
                    <div class="log-container">
                        <?php
                        // Показываем последние N строк
                        $logs_to_display = array_slice($logs, -$lines_to_show);
                        
                        foreach (array_reverse($logs_to_display) as $log) {
                            $class = 'log-line';
                            
                            if (strpos($log, '[INFO]') !== false) {
                                $class .= ' info';
                            } elseif (strpos($log, '[SUCCESS]') !== false) {
                                $class .= ' success';
                            } elseif (strpos($log, '[WARNING]') !== false) {
                                $class .= ' warning';
                            } elseif (strpos($log, '[ERROR]') !== false) {
                                $class .= ' error';
                            } elseif (strpos($log, '[DEBUG]') !== false) {
                                $class .= ' debug';
                            }
                            
                            // Выделяем временную метку
                            $log = preg_replace('/^\[(.*?)\]/', '<span class="timestamp">[$1]</span>', $log);
                            
                            echo "<div class='$class'>$log</div>";
                        }
                        
                        if ($total_lines > $lines_to_show) {
                            echo "<div style='text-align: center; color: #6c757d; margin-top: 20px;'>";
                            echo "Показаны последние $lines_to_show из $total_lines записей";
                            echo "</div>";
                        }
                        ?>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="no-data">
                        <p>Файл логов не найден или пуст</p>
                        <p style="color: #6c757d;">Логи появятся после первой попытки регистрации</p>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>