<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>САПОТВОРЕНИЕ - Фестиваль SUP-досок</title>
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8fafc;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Hero Section */
        .hero {
            position: relative;
            height: 100vh;
            min-height: 600px;
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .hero-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 25%, #0369a1 50%, #1e40af 75%, #1e3a8a 100%);
            background-size: 400% 400%;
            animation: gradientShift 8s ease infinite;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3);
            z-index: 1;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            text-align: center;
            color: white;
        }

        .logo-img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin-bottom: 20px;
            border: 4px solid rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
        }

        .hero-title {
            font-size: 4rem;
            font-weight: 800;
            margin-bottom: 20px;
            text-shadow: 2px 2px 20px rgba(0, 0, 0, 0.5);
            letter-spacing: -2px;
        }

        .hero-subtitle {
            font-size: 1.5rem;
            margin-bottom: 40px;
            opacity: 0.9;
            font-weight: 300;
        }

        .event-info {
            display: flex;
            gap: 30px;
            justify-content: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .info-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 15px 25px;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
        }

        .info-icon {
            font-size: 1.5rem;
        }

        .registration-btn {
            background: linear-gradient(135deg, #22c55e, #16a34a);
            color: white;
            padding: 25px 50px;
            border-radius: 20px;
            margin-top: 20px;
            box-shadow: 0 10px 30px rgba(34, 197, 94, 0.4);
            border: none;
            font-size: 1.2rem;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            animation: pulse 2s infinite;
        }

        .registration-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(34, 197, 94, 0.5);
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .registration-status {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            padding: 30px;
            border-radius: 20px;
            margin-top: 30px;
            border: 2px solid rgba(255, 255, 255, 0.2);
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .registration-status h3 {
            font-size: 1.8rem;
            margin-bottom: 15px;
            color: #fef3c7;
        }

        .registration-status p {
            font-size: 1.1rem;
            line-height: 1.7;
            margin-bottom: 10px;
        }

        /* About Section */
        .about {
            padding: 100px 0;
            background: white;
        }

        .about h2 {
            font-size: 3rem;
            text-align: center;
            margin-bottom: 30px;
            color: #1e293b;
            font-weight: 700;
        }

        .about p {
            font-size: 1.2rem;
            text-align: center;
            max-width: 800px;
            margin: 0 auto 60px;
            color: #64748b;
            line-height: 1.8;
        }

        .program h3 {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 40px;
            color: #1e293b;
        }

        .timeline {
            max-width: 600px;
            margin: 0 auto;
        }

        .timeline-item {
            display: flex;
            align-items: center;
            padding: 20px 0;
            border-bottom: 1px solid #e2e8f0;
        }

        .timeline-item:last-child {
            border-bottom: none;
        }

        .time {
            font-weight: 700;
            color: #0891b2;
            min-width: 150px;
            font-size: 1.1rem;
        }

        .event {
            color: #475569;
            font-size: 1.1rem;
        }

        /* Important Info Section */
        .important-info {
            padding: 80px 0;
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
        }

        .important-info h2 {
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 50px;
            color: #1e293b;
            font-weight: 700;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .info-item {
            background: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .info-item:hover {
            transform: translateY(-5px);
        }

        .info-item .icon {
            font-size: 3rem;
            margin-bottom: 15px;
            display: block;
        }

        .info-item p {
            font-weight: 600;
            color: #475569;
            font-size: 1.1rem;
        }

        /* VK Icon Styles */
        .vk-icon-container {
            width: 60px;
            height: 60px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .vk-svg {
            width: 100%;
            height: 100%;
            transition: transform 0.3s ease;
        }

        .info-item:hover .vk-svg {
            transform: scale(1.1);
        }

        /* Animations */
        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.2rem;
            }
            
            .event-info {
                flex-direction: column;
                align-items: center;
            }
            
            .info-card {
                width: 100%;
                max-width: 300px;
            }
            
            .registration-closed {
                padding: 20px 30px;
                font-size: 1rem;
            }
            
            .registration-status {
                padding: 20px;
                margin-top: 20px;
            }
            
            .registration-status h3 {
                font-size: 1.4rem;
            }
            
            .about h2 {
                font-size: 2rem;
            }
            
            .timeline-item {
                flex-direction: column;
                text-align: center;
                gap: 10px;
            }
            
            .time {
                min-width: auto;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .registration-closed {
                padding: 15px 25px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-background"></div>
        <div class="container">
            <div class="hero-content">
                <div class="logo">
                    <img src="logo.png" alt="САПОТВОРЕНИЕ" class="logo-img">
                </div>
                <h1 class="hero-title">САПОТВОРЕНИЕ</h1>
                <p class="hero-subtitle">Первый народный фестиваль на SUP-досках</p>
                <div class="event-info">
                    <div class="info-card">
                        <span class="info-icon">📅</span>
                        <span>13.07.2025 09:30</span>
                    </div>
                    <div class="info-card">
                        <span class="info-icon">📍</span>
                        <span>г. Старый Оскол, ВМЕСТЕ ПАРК</span>
                    </div>
                </div>
                
                <a href="registration.html" class="registration-btn">
                    🎉 РЕГИСТРАЦИЯ ОТКРЫТА
                </a>
                
                <div class="registration-status">
                    <h3>✅ Регистрация на фестиваль открыта!</h3>
                    <p><strong>Зарегистрируйтесь на участие в фестивале до 07.07.2025!</strong></p>
                    <p>Количество мест ограничено</p>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about">
        <div class="container">
            <h2>О фестивале</h2>
            <p>Фестиваль обещает стать ярким событием, объединяющим любителей активного отдыха и ценителей русской культуры. Помимо захватывающих заплывов на сапах в национальных костюмах, гости смогут погрузиться в мир старинных ремесел.</p>
            
            <div class="program">
                <h3>Программа фестиваля</h3>
                <div class="timeline">
                    <div class="timeline-item">
                        <span class="time">9:30</span>
                        <span class="event">Регистрация участников</span>
                    </div>
                    <div class="timeline-item">
                        <span class="time">11:00-13:00</span>
                        <span class="event">Мастер-классы и SUP-йога</span>
                    </div>
                    <div class="timeline-item">
                        <span class="time">13:00-15:00</span>
                        <span class="event">Массовый заплыв в костюмах</span>
                    </div>
                    <div class="timeline-item">
                        <span class="time">15:30-17:30</span>
                        <span class="event">Хороводы и SUP-поло</span>
                    </div>
                    <div class="timeline-item">
                        <span class="time">17:30</span>
                        <span class="event">Лотерея с призами</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Important Info -->
    <section class="important-info">
        <div class="container">
            <h2>Важная информация</h2>
            <div class="info-grid">
                <div class="info-item">
                    <span class="icon">🆔</span>
                    <p>Вход только по документам</p>
                </div>
                <div class="info-item">
                    <span class="icon">🦺</span>
                    <p>Спасательные жилеты обязательны</p>
                </div>
                <div class="info-item">
                    <span class="icon">💰</span>
                    <p>Имейте наличные деньги</p>
                </div>
                <div class="info-item">
                    <span class="icon">🏄‍♀️</span>
                    <p>Бесплатное обучение SUP</p>
                </div>
                <div class="info-item">
                    <span class="icon">✅</span>
                    <p>Регистрация открыта до 07.07.2025</p>
                </div>
                <div class="info-item">
                    <span class="icon">⚠️</span>
                    <p>Требуется соблюдение правил безопасности на воде</p>
                </div>
                <a href="https://vk.com/topic-219650565_53165077" target="_blank" class="info-item">
                    <div class="vk-icon-container">
                        <svg class="vk-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="111" viewBox="0 0 30 30.000001" height="120" preserveAspectRatio="xMidYMid meet" version="1.0">
                            <defs>
                                <clipPath id="id1">
                                    <path d="M 2.371094 2.394531 L 26 2.394531 L 26 26 L 2.371094 26 Z M 2.371094 2.394531" clip-rule="nonzero"></path>
                                </clipPath>
                            </defs>
                            <g clip-path="url(#id1)">
                                <path fill="#0077ff" d="M 13.496094 2.597656 C 10.730469 2.804688 8.210938 3.941406 6.230469 5.875 C 3.625 8.414062 2.375 12.011719 2.839844 15.625 C 3.414062 20.140625 6.601562 23.902344 10.976562 25.234375 C 14.359375 26.265625 18.125 25.652344 20.992188 23.613281 C 24.515625 21.101562 26.347656 16.9375 25.804688 12.675781 C 25.230469 8.15625 22.042969 4.394531 17.667969 3.0625 C 16.304688 2.660156 14.914062 2.503906 13.496094 2.601562 Z M 14.378906 9.773438 C 14.96875 9.832031 15.265625 9.925781 15.398438 10.097656 C 15.433594 10.144531 15.488281 10.261719 15.523438 10.359375 C 15.589844 10.5625 15.59375 10.792969 15.550781 12.527344 C 15.523438 13.609375 15.539062 13.945312 15.628906 14.183594 C 15.726562 14.460938 15.960938 14.585938 16.164062 14.480469 C 16.347656 14.382812 16.777344 13.914062 17.058594 13.492188 C 17.707031 12.53125 18.101562 11.789062 18.574219 10.640625 C 18.671875 10.414062 18.800781 10.261719 18.933594 10.226562 C 18.984375 10.210938 19.742188 10.199219 20.667969 10.195312 L 22.308594 10.191406 L 22.449219 10.25 C 22.632812 10.304688 22.714844 10.429688 22.695312 10.621094 C 22.695312 10.980469 22.320312 11.722656 21.675781 12.625 C 21.585938 12.75 21.253906 13.195312 20.933594 13.613281 C 20.230469 14.535156 20.078125 14.75 19.972656 14.976562 C 19.835938 15.257812 19.871094 15.492188 20.082031 15.765625 C 20.140625 15.84375 20.453125 16.15625 20.769531 16.460938 C 21.65625 17.3125 22.058594 17.757812 22.386719 18.246094 C 22.621094 18.601562 22.714844 18.859375 22.675781 19.085938 C 22.65625 19.207031 22.535156 19.355469 22.394531 19.425781 C 22.230469 19.511719 21.976562 19.527344 20.582031 19.546875 L 19.261719 19.5625 L 19.046875 19.492188 C 18.503906 19.3125 18.140625 19.007812 17.316406 18.054688 C 16.859375 17.527344 16.519531 17.265625 16.285156 17.265625 C 16.070312 17.265625 15.789062 17.550781 15.679688 17.910156 C 15.597656 18.148438 15.570312 18.335938 15.542969 18.75 C 15.515625 19.246094 15.457031 19.355469 15.15625 19.480469 C 15.046875 19.53125 13.683594 19.546875 13.324219 19.507812 C 12.601562 19.429688 11.933594 19.199219 11.269531 18.8125 C 10.304688 18.25 9.714844 17.742188 9.082031 16.9375 C 7.984375 15.53125 7.234375 14.335938 6.324219 12.535156 C 5.976562 11.832031 5.558594 10.925781 5.492188 10.707031 C 5.425781 10.484375 5.519531 10.300781 5.738281 10.230469 C 5.8125 10.207031 6.234375 10.195312 7.191406 10.179688 L 8.539062 10.167969 L 8.695312 10.226562 C 8.941406 10.320312 9.042969 10.445312 9.214844 10.851562 C 9.359375 11.195312 10.136719 12.753906 10.378906 13.191406 C 10.628906 13.628906 10.890625 14 11.121094 14.214844 C 11.402344 14.492188 11.527344 14.558594 11.726562 14.542969 C 11.894531 14.527344 11.9375 14.488281 12.042969 14.261719 C 12.296875 13.714844 12.335938 11.867188 12.109375 11.140625 C 11.980469 10.726562 11.785156 10.570312 11.246094 10.453125 C 11.152344 10.433594 11.152344 10.398438 11.238281 10.273438 C 11.445312 9.976562 11.816406 9.832031 12.523438 9.773438 C 12.910156 9.742188 14.058594 9.738281 14.375 9.773438 Z M 14.378906 9.773438" fill-opacity="1" fill-rule="nonzero"></path>
                            </g>
                        </svg>
                    </div>
                    <p>Следите за новостями в нашем сообществе ВК</p>
                </a>
            </div>
        </div>
    </section>

</body>
</html>