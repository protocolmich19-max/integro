<?php
// ВКЛЮЧАЕМ ОТОБРАЖЕНИЕ ОШИБОК
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Глобальные переменные для Google Sheets
$spreadsheet_id = '1KrCPs620PGaFXRWqrkqwvZGD_G9L5K91Ct74gVq6pqs';
$sheet_name = 'Регистрация';
$service_account_file = 'service-account.json';

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function getAccessToken() {
    global $service_account_file;
    if (!file_exists($service_account_file)) {
        return false;
    }
    $credentials = json_decode(file_get_contents($service_account_file), true);
    if (!$credentials) {
        return false;
    }
    $jwt_header = base64url_encode(json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]));
    $now = time();
    $jwt_payload = base64url_encode(json_encode([
        'iss' => $credentials['client_email'],
        'scope' => 'https://www.googleapis.com/auth/spreadsheets.readonly',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600
    ]));
    $jwt_signing_input = $jwt_header . '.' . $jwt_payload;
    $private_key = openssl_pkey_get_private($credentials['private_key']);
    if (!$private_key) {
        return false;
    }
    openssl_sign($jwt_signing_input, $signature, $private_key, OPENSSL_ALGO_SHA256);
    $jwt = $jwt_signing_input . '.' . base64url_encode($signature);
    $token_request = [
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ];
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($token_request),
            'ignore_errors' => true
        ]
    ]);
    $response = @file_get_contents('https://oauth2.googleapis.com/token', false, $context);
    if ($response === false) {
        return false;
    }
    $token_data = json_decode($response, true);
    return isset($token_data['access_token']) ? $token_data['access_token'] : false;
}

function getParticipants() {
    global $spreadsheet_id, $sheet_name;
    $access_token = getAccessToken();
    if (!$access_token) {
        error_log("[ERROR] Не удалось получить токен доступа");
        return false;
    }
    $range = $sheet_name . '!A:O';
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}";
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ],
            'ignore_errors' => true
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    if ($response === false) {
        error_log("[ERROR] Не удалось получить данные из Google Sheets");
        return false;
    }
    $data = json_decode($response, true);
    if (!isset($data['values']) || count($data['values']) < 2) {
        return [];
    }
    $participants = [];
    for ($i = 1; $i < count($data['values']); $i++) {
        $row = $data['values'][$i];
        $participants[] = [
            'code' => isset($row[0]) ? $row[0] : '',
            'date' => isset($row[1]) ? $row[1] : '',
            'surname' => isset($row[2]) ? $row[2] : '',
            'name' => isset($row[3]) ? $row[3] : '',
            'patronymic' => isset($row[4]) ? $row[4] : '',
            'birthdate' => isset($row[5]) ? $row[5] : '',
            'city' => isset($row[6]) ? $row[6] : '',
            'phone' => isset($row[7]) ? $row[7] : '',
            'email' => isset($row[8]) ? $row[8] : '',
            'children' => isset($row[9]) ? $row[9] : '',
            'sup_count' => isset($row[10]) ? intval($row[10]) : 0,
            'sup_cost' => isset($row[11]) ? intval($row[11]) : 0,
            'payment_status' => isset($row[12]) ? $row[12] : '',
            'user_id' => isset($row[13]) ? $row[13] : '',
            'timestamp' => isset($row[14]) ? $row[14] : ''
        ];
    }
    return array_reverse($participants);
}

// Функция для безопасного создания имени файла на русском языке
function createSafeFilename($surname, $date, $code) {
    // Убираем пустые значения
    $surname = trim($surname);
    $date = trim($date);
    $code = trim($code);
    
    // Если фамилия пустая, используем код или номер
    if (empty($surname)) {
        if (!empty($code)) {
            $base_name = 'Участник_' . $code;
        } else {
            $base_name = 'Участник_' . uniqid();
        }
    } else {
        // Очищаем фамилию от опасных символов, оставляя кириллицу
        $surname_clean = preg_replace('/[\/\\\:*?"<>|]/', '_', $surname);
        $base_name = $surname_clean;
    }
    
    // Добавляем дату регистрации если есть
    if (!empty($date)) {
        // Преобразуем дату в безопасный формат
        $date_clean = preg_replace('/[\/\\\:*?"<>|]/', '_', $date);
        $base_name .= '_' . $date_clean;
    }
    
    // Добавляем код если есть
    if (!empty($code)) {
        $code_clean = preg_replace('/[\/\\\:*?"<>|]/', '_', $code);
        $base_name .= '_' . $code_clean;
    }
    
    return 'Согласие_' . $base_name . '.docx';
}

require_once 'vendor/autoload.php';

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\Style\Font;
use PhpOffice\PhpWord\SimpleType\Jc;

// Получаем участников
$participants = getParticipants();

if ($participants === false || count($participants) === 0) {
    die('Нет участников для генерации соглашений');
}

// Создаем временную папку для документов
$temp_dir = 'temp_agreements_' . date('YmdHis');
if (!mkdir($temp_dir)) {
    die('Не удалось создать временную папку');
}

// Генерируем документ для каждого участника
foreach ($participants as $index => $participant) {
    $phpWord = new PhpWord();
    
    // Настройки документа
    $phpWord->setDefaultFontName('Times New Roman');
    $phpWord->setDefaultFontSize(12);
    
    $section = $phpWord->addSection();
    
    // Заголовок
    $section->addText(
        'ДОБРОВОЛЬНОЕ СОГЛАСИЕ И ОБЯЗАТЕЛЬСТВА УЧАСТНИКА',
        array('bold' => true, 'size' => 16),
        array('alignment' => Jc::CENTER)
    );
    
    $section->addText(
        'МЕРОПРИЯТИЯ НА ВОДЕ НА САП ДОСКАХ',
        array('bold' => true, 'size' => 14),
        array('alignment' => Jc::CENTER)
    );
    
    $section->addText(
        'ПРАВИЛА ПОВЕДЕНИЯ И ТЕХНИКА БЕЗОПАСНОСТИ',
        array('bold' => true, 'size' => 12),
        array('alignment' => Jc::CENTER)
    );
    
    $section->addTextBreak();
    
    // Информация об участнике
    $fio = trim($participant['surname'] . ' ' . $participant['name'] . ' ' . $participant['patronymic']);
    if (empty($fio)) {
        $fio = '______________________________';
    }
    
    $section->addText(
        'Я, ' . $fio . ',',
        array('bold' => true)
    );
    $section->addText('(ФИО полностью)');
    $section->addTextBreak();
    
    $birthdate = !empty($participant['birthdate']) ? $participant['birthdate'] : '____________';
    $city = !empty($participant['city']) ? $participant['city'] : '____________';
    $phone = !empty($participant['phone']) ? $participant['phone'] : '____________';
    
    $section->addText(
        'дата рождения: ' . $birthdate . ', город проживания: ' . $city . ', контактный телефон: ' . $phone . ','
    );
    $section->addTextBreak();
    
    $section->addText(
        'добровольно и осознанно подтверждаю свое согласие на участие в мероприятии на воде на САП досках, проводимом САП Клубом «ПриПраВа®», и обязуюсь соблюдать следующие правила:'
    );
    $section->addTextBreak();
    
    // 1. ОБЩИЕ ПОЛОЖЕНИЯ
    $section->addText('1. ОБЩИЕ ПОЛОЖЕНИЯ', array('bold' => true, 'size' => 12));
    $section->addText('1.1. Настоящее соглашение регулирует отношения между участником (мной) и организатором – клуб ПриПраВа® в рамках фестиваля.');
    $section->addText('1.2. Организатор оставляет за собой право изменять программу мероприятия, зоны проведения и другие условия в случае форс-мажорных обстоятельств.');
    $section->addTextBreak();
    
    // 2. ОТВЕТСТВЕННОСТЬ УЧАСТНИКА
    $section->addText('2. ОТВЕТСТВЕННОСТЬ УЧАСТНИКА', array('bold' => true, 'size' => 12));
    $section->addText('2.1. Я осознаю риски, связанные с участием в активностях на воде, и принимаю полную ответственность за:');
    $section->addText('- свою жизнь и здоровье;');
    $section->addText('- жизнь и здоровье несовершеннолетних детей, находящихся под моей опекой:');
    
    // Обработка детей
    if (!empty($participant['children'])) {
        $children = explode(',', $participant['children']);
        foreach ($children as $child) {
            $child = trim($child);
            if (!empty($child)) {
                $section->addText('  • ФИО и дата рождения ребенка: ' . $child);
            }
        }
    } else {
        // Пустые строки для детей
        $section->addText('  • ФИО и дата рождения ребенка: __________________________________');
        $section->addText('  • ФИО и дата рождения ребенка: __________________________________');
        $section->addText('  • ФИО и дата рождения ребенка: __________________________________');
    }
    
    $section->addText('2.2. В случае аренды оборудования обязуюсь:');
    $section->addText('- возместить стоимость повреждения или утери по ценам закупки на дату ущерба;');
    $section->addText('- следовать инструкциям по эксплуатации.');
    $section->addTextBreak();
    
    // 3. ТРЕБОВАНИЯ К УЧАСТНИКУ
    $section->addText('3. ТРЕБОВАНИЯ К УЧАСТНИКУ', array('bold' => true, 'size' => 12));
    $section->addText('3.1. Я подтверждаю, что:');
    $section->addText('- не имею медицинских противопоказаний к физическим нагрузкам;');
    $section->addText('- умею плавать;');
    $section->addText('- не нахожусь в состоянии алкогольного/наркотического опьянения.');
    $section->addText('3.2. Обязуюсь:');
    $section->addText('- использовать спасательный жилет и лиш (не снимать их на воде);');
    $section->addText('- не заходить в зоны купания или движения моторных судов;');
    $section->addText('- следовать указаниям организаторов.');
    $section->addTextBreak();
    
    // 4. БЕЗОПАСНОСТЬ И ФОРС-МАЖОР
    $section->addText('4. БЕЗОПАСНОСТЬ И ФОРС-МАЖОР', array('bold' => true, 'size' => 12));
    $section->addText('4.1. В случае ЧС обязуюсь следовать указаниям спасателей или ГО ЧС.');
    $section->addText('4.2. Организатор не несет ответственности за:');
    $section->addText('- утерю/повреждение личных вещей;');
    $section->addText('- травмы, полученные из-за нарушения правил участником.');
    $section->addTextBreak();
    
    // 5. ИСПОЛЬЗОВАНИЕ ПЕРСОНАЛЬНЫХ ДАННЫХ И МЕДИА
    $section->addText('5. ИСПОЛЬЗОВАНИЕ ПЕРСОНАЛЬНЫХ ДАННЫХ И МЕДИA', array('bold' => true, 'size' => 12));
    $section->addText('5.1. Даю согласие на обработку моих персональных данных в рамках мероприятия.');
    $section->addText('5.2. Разрешаю использование моего изображения в рекламных материалах без компенсации.');
    $section->addTextBreak();
    
    // 6. ПРОЧИЕ УСЛОВИЯ
    $section->addText('6. ПРОЧИЕ УСЛОВИЯ', array('bold' => true, 'size' => 12));
    $section->addText('6.1. Нарушение правил влечет удаление с мероприятия без компенсации.');
    $section->addText('6.2. Вход на территорию — только при предъявлении паспорта, свидетельства о рождения для несовершеннолетних.');
    $section->addTextBreak(2);
    
    // Подпись и дата
    $section->addText('Дата: __________' . date('Y') . 'г.                    Подпись: ___________________');
    $section->addTextBreak(2);
    
    // Информация об организаторе
    $section->addText('Организатор:', array('bold' => true));
    $section->addText('САП Клуб «ПриПраВа®»');
    $section->addText('Контактный телефон: 8-910-322-64-40');
    $section->addText('Email: priprava31@gmail.com');
    
    // Создаем безопасное имя файла на русском языке
    $filename = createSafeFilename($participant['surname'], $participant['date'], $participant['code']);
    
    $objWriter = IOFactory::createWriter($phpWord, 'Word2007');
    $objWriter->save($temp_dir . '/' . $filename);
}

// Создаем ZIP архив
$zip_filename = 'agreements_' . date('Y-m-d_H-i-s') . '.zip';
$zip = new ZipArchive();

if ($zip->open($zip_filename, ZipArchive::CREATE) === TRUE) {
    // Добавляем все файлы из временной папки
    $files = glob($temp_dir . '/*.docx');
    foreach ($files as $file) {
        $zip->addFile($file, basename($file));
    }
    $zip->close();
    
    // Удаляем временные файлы
    foreach ($files as $file) {
        unlink($file);
    }
    rmdir($temp_dir);
    
    // Отправляем ZIP файл
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
    header('Content-Length: ' . filesize($zip_filename));
    readfile($zip_filename);
    
    // Удаляем ZIP файл после отправки
    unlink($zip_filename);
    exit;
} else {
    die('Не удалось создать ZIP архив');
}
?>