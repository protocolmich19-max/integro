<?php
header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Настройки Google Sheets
$spreadsheet_id = '1KrCPs620PGaFXRWqrkqwvZGD_G9L5K91Ct74gVq6pqs';
$sheet_name = 'Регистрация';
$service_account_file = 'service-account.json';

// Функция для base64url кодирования
function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

// Массив для хранения результатов тестов
$tests = [];
$overall_success = true;

// Функция для добавления результата теста
function addTest($name, $status, $message = '', $details = '') {
    global $tests, $overall_success;
    $tests[] = [
        'name' => $name,
        'status' => $status,
        'message' => $message,
        'details' => $details
    ];
    if (!$status) {
        $overall_success = false;
    }
}

// Выполнение тестов
try {
    // Тест 1: Проверка файла сервисного аккаунта
    if (!file_exists($service_account_file)) {
        addTest('Файл сервисного аккаунта', false, 'Файл не найден', 'Убедитесь, что файл service-account.json находится в той же директории');
    } else {
        addTest('Файл сервисного аккаунта', true, 'Файл найден');
    }

    // Тест 2: Чтение credentials
    if (file_exists($service_account_file)) {
        $credentials = json_decode(file_get_contents($service_account_file), true);
        if (!$credentials) {
            addTest('Чтение credentials', false, 'Не удалось прочитать JSON', 'Проверьте формат файла service-account.json');
        } else {
            addTest('Чтение credentials', true, 'JSON прочитан успешно', 'Email: ' . $credentials['client_email']);
        }

        // Тест 3: Создание JWT
        if ($credentials) {
            $jwt_header = base64url_encode(json_encode([
                'alg' => 'RS256',
                'typ' => 'JWT'
            ]));
            
            $now = time();
            $jwt_payload = base64url_encode(json_encode([
                'iss' => $credentials['client_email'],
                'scope' => 'https://www.googleapis.com/auth/spreadsheets',
                'aud' => 'https://oauth2.googleapis.com/token',
                'iat' => $now,
                'exp' => $now + 3600
            ]));
            
            $jwt_signing_input = $jwt_header . '.' . $jwt_payload;
            
            $private_key = openssl_pkey_get_private($credentials['private_key']);
            if (!$private_key) {
                addTest('Создание JWT токена', false, 'Ошибка приватного ключа', 'Проверьте корректность private_key в service-account.json');
            } else {
                openssl_sign($jwt_signing_input, $signature, $private_key, OPENSSL_ALGO_SHA256);
                $jwt = $jwt_signing_input . '.' . base64url_encode($signature);
                addTest('Создание JWT токена', true, 'Токен создан успешно');

                // Тест 4: Получение access token
                $token_request = [
                    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                    'assertion' => $jwt
                ];
                
                $context = stream_context_create([
                    'http' => [
                        'method' => 'POST',
                        'header' => 'Content-Type: application/x-www-form-urlencoded',
                        'content' => http_build_query($token_request),
                        'ignore_errors' => true
                    ]
                ]);
                
                $response = @file_get_contents('https://oauth2.googleapis.com/token', false, $context);
                
                if ($response === false) {
                    addTest('Получение access token', false, 'Нет ответа от Google', 'Проверьте интернет-соединение');
                } else {
                    $token_data = json_decode($response, true);
                    
                    if (!isset($token_data['access_token'])) {
                        addTest('Получение access token', false, 'Токен не получен', isset($token_data['error']) ? $token_data['error'] : 'Неизвестная ошибка');
                    } else {
                        $access_token = $token_data['access_token'];
                        addTest('Получение access token', true, 'Токен получен успешно');

                        // Тест 5: Проверка доступа к таблице
                        $spreadsheet_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}";
                        
                        $context = stream_context_create([
                            'http' => [
                                'method' => 'GET',
                                'header' => [
                                    'Authorization: Bearer ' . $access_token,
                                    'Content-Type: application/json'
                                ],
                                'ignore_errors' => true
                            ]
                        ]);
                        
                        $response = @file_get_contents($spreadsheet_url, false, $context);
                        
                        if ($response === false) {
                            addTest('Доступ к таблице', false, 'Не удалось подключиться', 'Проверьте ID таблицы');
                        } else {
                            $spreadsheet_data = json_decode($response, true);
                            
                            if (isset($spreadsheet_data['error'])) {
                                $error_msg = $spreadsheet_data['error']['message'] ?? 'Неизвестная ошибка';
                                $help = "Откройте таблицу → Поделиться → Добавьте: " . $credentials['client_email'];
                                addTest('Доступ к таблице', false, $error_msg, $help);
                            } else {
                                $title = $spreadsheet_data['properties']['title'] ?? 'Без названия';
                                addTest('Доступ к таблице', true, 'Подключено успешно', 'Таблица: ' . $title);

                                // Тест 6: Проверка листов
                                $sheets_found = false;
                                $sheet_list = [];
                                foreach ($spreadsheet_data['sheets'] as $sheet) {
                                    $sheet_title = $sheet['properties']['title'];
                                    $sheet_list[] = $sheet_title;
                                    if ($sheet_title === $sheet_name) {
                                        $sheets_found = true;
                                    }
                                }
                                
                                if ($sheets_found) {
                                    addTest('Лист "' . $sheet_name . '"', true, 'Лист найден', 'Листы: ' . implode(', ', $sheet_list));
                                } else {
                                    addTest('Лист "' . $sheet_name . '"', true, 'Лист будет создан автоматически', 'Существующие листы: ' . implode(', ', $sheet_list));
                                }

                                // Тест 7: Чтение данных
                                $range = $sheet_name . '!A1:O10';
                                $values_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}";
                                
                                $context = stream_context_create([
                                    'http' => [
                                        'method' => 'GET',
                                        'header' => [
                                            'Authorization: Bearer ' . $access_token,
                                            'Content-Type: application/json'
                                        ],
                                        'ignore_errors' => true
                                    ]
                                ]);
                                
                                $response = @file_get_contents($values_url, false, $context);
                                $values_data = json_decode($response, true);
                                
                                if (isset($values_data['values'])) {
                                    $row_count = count($values_data['values']);
                                    addTest('Чтение данных', true, "Прочитано {$row_count} строк", $row_count > 0 ? 'Данные доступны для чтения' : 'Лист пустой');
                                } else {
                                    addTest('Чтение данных', true, 'Лист пока пустой', 'Данные появятся после первой регистрации');
                                }
                            }
                        }
                    }
                }
            }
        }
    }
} catch (Exception $e) {
    addTest('Системная ошибка', false, $e->getMessage());
}

// Системная информация
$system_info = [
    'PHP версия' => phpversion(),
    'OpenSSL' => extension_loaded('openssl') ? 'Установлен' : 'Не установлен',
    'JSON' => extension_loaded('json') ? 'Установлен' : 'Не установлен',
    'Память' => ini_get('memory_limit'),
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тест подключения к Google Sheets</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            background: linear-gradient(135deg, #4a69bd 0%, #6c5ce7 100%);
            color: white;
            padding: 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 3s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.3; }
            50% { transform: scale(1.1); opacity: 0.1; }
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }

        .status-banner {
            padding: 20px 40px;
            text-align: center;
            font-weight: bold;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }

        .status-banner.success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
        }

        .status-banner.error {
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            color: white;
        }

        .tests-container {
            padding: 40px;
        }

        .test-item {
            background: #f7fafc;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            animation: fadeIn 0.5s ease forwards;
            opacity: 0;
        }

        .test-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }

        .test-item.success {
            border-color: #48bb78;
        }

        .test-item.error {
            border-color: #f56565;
        }

        .test-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 20px;
            flex-shrink: 0;
        }

        .test-icon.success {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            color: white;
        }

        .test-icon.error {
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            color: white;
        }

        .test-content {
            flex: 1;
        }

        .test-name {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: #2d3748;
        }

        .test-message {
            color: #718096;
            margin-bottom: 5px;
        }

        .test-details {
            font-size: 0.9rem;
            color: #a0aec0;
            background: #edf2f7;
            padding: 8px 12px;
            border-radius: 6px;
            margin-top: 8px;
            display: inline-block;
        }

        .system-info {
            background: #f7fafc;
            padding: 30px 40px;
            border-top: 2px solid #e2e8f0;
        }

        .system-info h2 {
            color: #2d3748;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .info-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
        }

        .info-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .info-label {
            font-size: 0.9rem;
            color: #718096;
            margin-bottom: 5px;
        }

        .info-value {
            font-weight: 600;
            color: #2d3748;
            font-size: 1.1rem;
        }

        .actions {
            padding: 20px 40px 40px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #4a69bd 0%, #6c5ce7 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #4a5568;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid transparent;
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .help-text {
            background: #fef5e7;
            border-left: 4px solid #f39c12;
            padding: 15px 20px;
            margin: 20px 40px;
            border-radius: 4px;
            color: #856404;
        }

        .help-text strong {
            display: block;
            margin-bottom: 5px;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .header h1 {
                font-size: 2rem;
            }
            
            .tests-container {
                padding: 20px;
            }
            
            .test-item {
                padding: 15px;
            }
            
            .test-icon {
                width: 40px;
                height: 40px;
                font-size: 1.2rem;
                margin-right: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 Тест подключения к Google Sheets</h1>
            <p>Проверка конфигурации системы регистрации</p>
        </div>

        <div class="status-banner <?php echo $overall_success ? 'success' : 'error'; ?>">
            <?php if ($overall_success): ?>
                ✅ Все тесты пройдены успешно!
            <?php else: ?>
                ❌ Обнаружены проблемы. Проверьте детали ниже.
            <?php endif; ?>
        </div>

        <div class="tests-container">
            <?php foreach ($tests as $index => $test): ?>
                <div class="test-item <?php echo $test['status'] ? 'success' : 'error'; ?>" style="animation-delay: <?php echo $index * 0.1; ?>s">
                    <div class="test-icon <?php echo $test['status'] ? 'success' : 'error'; ?>">
                        <?php echo $test['status'] ? '✓' : '✗'; ?>
                    </div>
                    <div class="test-content">
                        <div class="test-name"><?php echo htmlspecialchars($test['name']); ?></div>
                        <?php if ($test['message']): ?>
                            <div class="test-message"><?php echo htmlspecialchars($test['message']); ?></div>
                        <?php endif; ?>
                        <?php if ($test['details']): ?>
                            <div class="test-details"><?php echo htmlspecialchars($test['details']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (!$overall_success && isset($credentials['client_email'])): ?>
            <div class="help-text">
                <strong>📌 Как предоставить доступ к таблице:</strong>
                1. Откройте вашу Google таблицу<br>
                2. Нажмите кнопку "Поделиться" (Share)<br>
                3. Добавьте email: <code><?php echo htmlspecialchars($credentials['client_email']); ?></code><br>
                4. Выберите роль "Редактор" (Editor)<br>
                5. Нажмите "Готово"
            </div>
        <?php endif; ?>

        <div class="system-info">
            <h2>💻 Информация о системе</h2>
            <div class="info-grid">
                <?php foreach ($system_info as $label => $value): ?>
                    <div class="info-item">
                        <div class="info-label"><?php echo htmlspecialchars($label); ?></div>
                        <div class="info-value"><?php echo htmlspecialchars($value); ?></div>
                    </div>
                <?php endforeach; ?>
                <div class="info-item">
                    <div class="info-label">Spreadsheet ID</div>
                    <div class="info-value" style="font-size: 0.8rem; word-break: break-all;">
                        <?php echo htmlspecialchars($spreadsheet_id); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="actions">
            <a href="test_sheets.php" class="btn btn-primary">
                <span class="loading"></span>
                Повторить тест
            </a>
            <a href="view_logs.php" class="btn btn-secondary">
                📋 Просмотр логов
            </a>
            <a href="index.html" class="btn btn-secondary">
                🏠 На главную
            </a>
            <?php if ($overall_success): ?>
                <a href="https://docs.google.com/spreadsheets/d/<?php echo $spreadsheet_id; ?>" target="_blank" class="btn btn-primary">
                    📊 Открыть таблицу
                </a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Убираем loading spinner после загрузки
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                document.querySelectorAll('.loading').forEach(el => el.style.display = 'none');
            }, 100);
        });
    </script>
</body>
</html>