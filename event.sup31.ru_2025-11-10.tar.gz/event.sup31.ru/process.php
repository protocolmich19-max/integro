<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Настройки Google Sheets
$spreadsheet_id = '1KrCPs620PGaFXRWqrkqwvZGD_G9L5K91Ct74gVq6pqs';
$sheet_name = 'Регистрация';
$service_account_file = 'service-account.json';
$log_file = 'google_sheets_log.txt';

// Настройки
$price_per_sup = 1500;

// Функция логирования
function writeLog($message, $type = 'INFO') {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[$timestamp] [$type] $message" . PHP_EOL;
    file_put_contents($log_file, $log_message, FILE_APPEND);
}

// Функция для base64url кодирования
function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

// Получение токена доступа
function getAccessToken() {
    global $service_account_file;
    
    try {
        if (!file_exists($service_account_file)) {
            throw new Exception("Файл сервисного аккаунта не найден");
        }

        $credentials = json_decode(file_get_contents($service_account_file), true);
        
        // Создаем JWT
        $jwt_header = base64url_encode(json_encode([
            'alg' => 'RS256',
            'typ' => 'JWT'
        ]));
        
        $now = time();
        $jwt_payload = base64url_encode(json_encode([
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/spreadsheets',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => $now,
            'exp' => $now + 3600
        ]));
        
        $jwt_signing_input = $jwt_header . '.' . $jwt_payload;
        
        $private_key = openssl_pkey_get_private($credentials['private_key']);
        if (!$private_key) {
            throw new Exception("Не удалось получить закрытый ключ");
        }
        
        openssl_sign($jwt_signing_input, $signature, $private_key, OPENSSL_ALGO_SHA256);
        $jwt = $jwt_signing_input . '.' . base64url_encode($signature);
        
        // Запрашиваем токен
        $token_request = [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ];
        
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => http_build_query($token_request),
                'ignore_errors' => true
            ]
        ]);
        
        $response = file_get_contents('https://oauth2.googleapis.com/token', false, $context);
        
        if ($response === false) {
            throw new Exception("Не удалось получить токен");
        }
        
        $token_data = json_decode($response, true);
        
        if (!isset($token_data['access_token'])) {
            throw new Exception("Токен отсутствует в ответе");
        }
        
        writeLog("Токен успешно получен", 'INFO');
        return $token_data['access_token'];
        
    } catch (Exception $e) {
        writeLog("Ошибка получения токена: " . $e->getMessage(), 'ERROR');
        throw $e;
    }
}

// Функция для отправки запросов к Google Sheets API
function makeRequest($url, $method = 'GET', $data = null, $access_token = null) {
    if (!$access_token) {
        $access_token = getAccessToken();
    }

    $context_options = [
        'http' => [
            'method' => $method,
            'header' => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ],
            'ignore_errors' => true
        ]
    ];

    if ($data !== null) {
        $context_options['http']['content'] = json_encode($data);
    }

    $context = stream_context_create($context_options);
    $response = file_get_contents($url, false, $context);
    
    if ($response === false) {
        writeLog("HTTP запрос не удался: $url", 'ERROR');
        throw new Exception("Ошибка HTTP запроса");
    }

    $response_data = json_decode($response, true);
    
    // Проверяем HTTP статус
    $http_response_header_str = implode("\n", $http_response_header);
    writeLog("HTTP Response Headers: " . $http_response_header_str, 'DEBUG');
    
    if (isset($response_data['error'])) {
        writeLog("API вернул ошибку: " . json_encode($response_data['error']), 'ERROR');
        throw new Exception("API error: " . $response_data['error']['message']);
    }

    return $response_data;
}

// Функция проверки существования листа и его создания
function ensureSheetExists() {
    global $spreadsheet_id, $sheet_name;
    
    try {
        $access_token = getAccessToken();
        
        // Получаем информацию о таблице
        $spreadsheet_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}";
        $spreadsheet_data = makeRequest($spreadsheet_url, 'GET', null, $access_token);
        
        writeLog("Полученные данные таблицы: " . json_encode($spreadsheet_data['sheets']), 'DEBUG');
        
        // Проверяем, существует ли лист
        $sheet_exists = false;
        $sheet_id = null;
        
        if (isset($spreadsheet_data['sheets'])) {
            foreach ($spreadsheet_data['sheets'] as $sheet) {
                if ($sheet['properties']['title'] === $sheet_name) {
                    $sheet_exists = true;
                    $sheet_id = $sheet['properties']['sheetId'];
                    writeLog("Лист '{$sheet_name}' найден с ID: {$sheet_id}", 'INFO');
                    break;
                }
            }
        }
        
        if (!$sheet_exists) {
            writeLog("Лист '{$sheet_name}' не найден. Создаем новый.", 'INFO');
            
            // Создаем новый лист
            $requests = [
                [
                    'addSheet' => [
                        'properties' => [
                            'title' => $sheet_name,
                            'gridProperties' => [
                                'rowCount' => 1000,
                                'columnCount' => 15
                            ]
                        ]
                    ]
                ]
            ];
            
            $batch_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}:batchUpdate";
            $result = makeRequest($batch_url, 'POST', ['requests' => $requests], $access_token);
            
            // Получаем ID нового листа
            if (isset($result['replies'][0]['addSheet']['properties']['sheetId'])) {
                $sheet_id = $result['replies'][0]['addSheet']['properties']['sheetId'];
                writeLog("Новый лист создан с ID: {$sheet_id}", 'INFO');
            }
            
            // Создаем заголовки для нового листа
            createHeaders($sheet_id);
        }
        
        return ['exists' => true, 'sheet_id' => $sheet_id];
        
    } catch (Exception $e) {
        writeLog("Ошибка при проверке/создании листа: " . $e->getMessage(), 'ERROR');
        throw $e;
    }
}

// Создание заголовков
function createHeaders($sheet_id = null) {
    global $spreadsheet_id, $sheet_name;
    
    try {
        $access_token = getAccessToken();
        
        $headers = [
            ['📋 Код регистрации', '📅 Дата регистрации', '👤 Фамилия', '👤 Имя', '👤 Отчество',
             '🎂 Дата рождения', '🏙️ Город', '📞 Телефон', '📧 Email', '🚌 Трансфер', '👶 Дети',
             '🏄 Кол-во SUP', '💰 Стоимость SUP', '💳 Статус оплаты', '🆔 ID пользователя', '⏰ Timestamp']
        ];
        
        $range = $sheet_name . '!A1:P1';
        $body = [
            'values' => $headers,
            'majorDimension' => 'ROWS'
        ];
        
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}?valueInputOption=RAW";
        $result = makeRequest($url, 'PUT', $body, $access_token);
        
        writeLog("Заголовки созданы: " . json_encode($result), 'INFO');
        
        // Форматируем заголовки
        if ($sheet_id !== null) {
            $requests = [
                [
                    'repeatCell' => [
                        'range' => [
                            'sheetId' => $sheet_id,
                            'startRowIndex' => 0,
                            'endRowIndex' => 1,
                            'startColumnIndex' => 0,
                            'endColumnIndex' => 16
                        ],
                        'cell' => [
                            'userEnteredFormat' => [
                                'backgroundColor' => ['red' => 0.2, 'green' => 0.6, 'blue' => 0.9],
                                'textFormat' => [
                                    'foregroundColor' => ['red' => 1, 'green' => 1, 'blue' => 1],
                                    'bold' => true,
                                    'fontSize' => 11
                                ]
                            ]
                        ],
                        'fields' => 'userEnteredFormat'
                    ]
                ],
                [
                    'updateSheetProperties' => [
                        'properties' => [
                            'sheetId' => $sheet_id,
                            'gridProperties' => ['frozenRowCount' => 1]
                        ],
                        'fields' => 'gridProperties.frozenRowCount'
                    ]
                ]
            ];
            
            $batch_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}:batchUpdate";
            makeRequest($batch_url, 'POST', ['requests' => $requests], $access_token);
            
            writeLog("Форматирование заголовков завершено", 'INFO');
        }
        
    } catch (Exception $e) {
        writeLog("Ошибка при создании заголовков: " . $e->getMessage(), 'ERROR');
        throw $e;
    }
}

// Добавление строки в таблицу
function appendRow($data) {
    global $spreadsheet_id, $sheet_name;
    
    try {
        // Убеждаемся, что лист существует
        $sheet_info = ensureSheetExists();
        
        $access_token = getAccessToken();
        
        $range = $sheet_name . '!A:P';
        $body = [
            'values' => [$data],
            'majorDimension' => 'ROWS'
        ];
        
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS";
        
        writeLog("Отправка запроса на добавление данных: " . json_encode($body), 'DEBUG');
        
        $result = makeRequest($url, 'POST', $body, $access_token);
        
        writeLog("Результат добавления: " . json_encode($result), 'INFO');
        
        if (isset($result['updates']['updatedRows']) && $result['updates']['updatedRows'] > 0) {
            writeLog("Данные успешно добавлены. Обновлено строк: " . $result['updates']['updatedRows'], 'SUCCESS');
            return true;
        } else {
            throw new Exception("Не удалось добавить данные в таблицу");
        }
        
    } catch (Exception $e) {
        writeLog("Ошибка при добавлении данных: " . $e->getMessage(), 'ERROR');
        throw $e;
    }
}

// Проверка дубликатов
function checkDuplicate($email, $phone) {
    global $spreadsheet_id, $sheet_name;
    
    try {
        $access_token = getAccessToken();
        
        $range = $sheet_name . '!H:I';
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}";
        
        $data = makeRequest($url, 'GET', null, $access_token);
        
        if (isset($data['values']) && count($data['values']) > 1) {
            // Пропускаем первую строку (заголовки)
            for ($i = 1; $i < count($data['values']); $i++) {
                $row = $data['values'][$i];
                if (count($row) >= 2) {
                    if ((isset($row[0]) && $row[0] === $phone) || 
                        (isset($row[1]) && $row[1] === $email)) {
                        writeLog("Найден дубликат для email: {$email} или телефона: {$phone}", 'INFO');
                        return true;
                    }
                }
            }
        }
        
        return false;
        
    } catch (Exception $e) {
        writeLog("Ошибка при проверке дубликатов: " . $e->getMessage(), 'ERROR');
        // В случае ошибки разрешаем регистрацию
        return false;
    }
}

// Функция генерации кода регистрации
function generateRegistrationCode() {
    $prefix = 'F48';
    $timestamp = time();
    $random = rand(1000, 9999);
    return $prefix . '-' . substr($timestamp, -6) . '-' . $random;
}

// НАЧАЛО ОБРАБОТКИ ЗАПРОСА
writeLog("=== Начало обработки новой регистрации ===", 'INFO');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    writeLog("Неверный метод запроса: " . $_SERVER['REQUEST_METHOD'], 'WARNING');
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Метод не разрешен']);
    exit;
}

// Логируем полученные данные
writeLog("Полученные POST данные: " . json_encode($_POST), 'DEBUG');

// Валидация данных формы
$required_fields = ['surname', 'name', 'birthdate', 'city', 'phone', 'email'];
$errors = [];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        $errors[] = "Поле '$field' обязательно для заполнения";
    }
}

// Валидация email
if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Неверный формат email";
}

// Валидация телефона
if (!empty($_POST['phone'])) {
    $phone_digits = preg_replace('/\D/', '', $_POST['phone']);
    if (strlen($phone_digits) !== 11) {
        $errors[] = "Телефон должен содержать 11 цифр";
    }
}

// Валидация даты рождения
if (!empty($_POST['birthdate'])) {
    $birthdate = DateTime::createFromFormat('Y-m-d', $_POST['birthdate']);
    if (!$birthdate) {
        $errors[] = "Неверный формат даты рождения";
    } else {
        $age = $birthdate->diff(new DateTime())->y;
        if ($age < 0 || $age > 120) {
            $errors[] = "Неверная дата рождения";
        }
    }
}

// Обработка данных о детях
$children = [];
if (isset($_POST['children']) && is_array($_POST['children'])) {
    foreach ($_POST['children'] as $child) {
        if (!empty($child['full_name']) && !empty($child['birth_date'])) {
            $children[] = $child;
        }
    }
}

// Обработка трансфера
$need_transport = isset($_POST['need_transport']) && $_POST['need_transport'] === 'on' ? 'Да' : 'Нет';
writeLog("need_transport: " . $need_transport, 'DEBUG');

// Обработка аренды SUP
$sap_rental_quantity = 0;
$sap_rental_cost = 0;

// Логируем данные о SUP
writeLog("need_sup: " . ($_POST['need_sup'] ?? 'not set'), 'DEBUG');
writeLog("sap_rental_quantity: " . ($_POST['sap_rental_quantity'] ?? 'not set'), 'DEBUG');

if (isset($_POST['need_sup']) && $_POST['need_sup'] === 'on') {
    $sap_rental_quantity = intval($_POST['sap_rental_quantity'] ?? 0);
    if ($sap_rental_quantity < 0) $sap_rental_quantity = 0;
    if ($sap_rental_quantity > 5) $sap_rental_quantity = 5;
    $sap_rental_cost = $sap_rental_quantity * $price_per_sup;
}

// Если есть ошибки, возвращаем их
if (!empty($errors)) {
    writeLog("Ошибки валидации: " . implode(", ", $errors), 'WARNING');
    echo json_encode([
        'success' => false,
        'message' => 'Ошибки валидации',
        'errors' => $errors
    ]);
    exit;
}

try {
    // Проверяем дубликаты
    if (checkDuplicate($_POST['email'], $_POST['phone'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Пользователь с таким email или телефоном уже зарегистрирован'
        ]);
        exit;
    }
    
    // Подготавливаем данные
    $registration_code = generateRegistrationCode();
    $registration_date = date('d.m.Y H:i');
    
    // Формируем строку с информацией о детях (через запятую)
    $children_text = '';
    if (!empty($children)) {
        $children_names = array_map(function($child) {
            return $child['full_name'] . ' (' . $child['birth_date'] . ')';
        }, $children);
        $children_text = implode(', ', $children_names);
    }
    
    // Подготавливаем данные для записи
    $row_data = [
        $registration_code,                    // Код регистрации
        $registration_date,                    // Дата регистрации
        trim($_POST['surname']),               // Фамилия
        trim($_POST['name']),                  // Имя
        trim($_POST['patronymic'] ?? ''),      // Отчество
        $_POST['birthdate'],                   // Дата рождения
        trim($_POST['city']),                  // Город
        $_POST['phone'],                       // Телефон
        trim($_POST['email']),                 // Email
        $need_transport,                       // Трансфер
        $children_text,                        // Информация о детях (через запятую)
        (string)$sap_rental_quantity,          // Количество SUP
        (string)$sap_rental_cost,              // Стоимость аренды
        $sap_rental_cost > 0 ? 'Ожидает оплаты' : 'Не требуется', // Статус оплаты
        uniqid('user_', true),                 // ID пользователя
        (string)time()                         // Timestamp
    ];
    
    writeLog("Подготовленные данные для записи: " . json_encode($row_data), 'DEBUG');
    
    // Записываем данные
    $append_result = appendRow($row_data);
    
    if ($append_result) {
        writeLog("✅ Регистрация успешно завершена для " . $_POST['email'], 'SUCCESS');
        
        echo json_encode([
            'success' => true,
            'message' => '🎉 Регистрация успешно завершена!',
            'data' => [
                'registration_code' => $registration_code,
                'registration_date' => $registration_date,
                'payment_status' => $sap_rental_cost > 0 ? 'pending' : 'free',
                'sap_rental_cost' => $sap_rental_cost,
                'sap_rental_quantity' => $sap_rental_quantity,
                'need_transport' => $need_transport === 'Да'
            ]
        ]);
    } else {
        throw new Exception("Не удалось сохранить данные в таблицу");
    }
    
} catch (Exception $e) {
    writeLog("❌ Критическая ошибка: " . $e->getMessage(), 'ERROR');
    writeLog("Stack trace: " . $e->getTraceAsString(), 'ERROR');
    
    echo json_encode([
        'success' => false,
        'message' => 'Произошла ошибка при регистрации. Пожалуйста, попробуйте позже.'
    ]);
}

writeLog("=== Конец обработки регистрации ===", 'INFO');
?>