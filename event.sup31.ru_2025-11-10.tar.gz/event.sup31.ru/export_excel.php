<?php
/*
 * Скрипт для выгрузки данных участников в Excel (XLSX).
 * Требует установленной библиотеки PhpSpreadsheet (через Composer).
 * Для работы нужно, чтобы getParticipants() по-прежнему было доступно.
 * Опционально можете перенести сюда функцию getParticipants() или использовать include.
 */

// ВКЛЮЧАЕМ ОТОБРАЖЕНИЕ ОШИБОК
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Подключаем автозагрузку Composer
require __DIR__ . '/vendor/autoload.php';

// Чтобы при проблемах с кодировкой в Excel файл читался корректно
header('Content-Type: text/html; charset=utf-8');

// Глобальные переменные для Google Sheets
$log_file = 'google_sheets_log.txt';
$lines_to_show = 100;
$spreadsheet_id = '1KrCPs620PGaFXRWqrkqwvZGD_G9L5K91Ct74gVq6pqs';
$sheet_name = 'Регистрация';
$service_account_file = 'service-account.json';

// ВАЖНО: не подключаем view_logs.php напрямую, чтобы не было вывода HTML
// Вместо этого копируем функцию getParticipants сюда (или делаем отдельный include только с функциями)
// Для теста временно копируем функцию getParticipants:

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function getAccessToken() {
    global $service_account_file;
    
    if (!file_exists($service_account_file)) {
        return false;
    }

    $credentials = json_decode(file_get_contents($service_account_file), true);
    if (!$credentials) {
        return false;
    }

    $jwt_header = base64url_encode(json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]));
    
    $now = time();
    $jwt_payload = base64url_encode(json_encode([
        'iss' => $credentials['client_email'],
        'scope' => 'https://www.googleapis.com/auth/spreadsheets.readonly',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600
    ]));
    
    $jwt_signing_input = $jwt_header . '.' . $jwt_payload;
    
    $private_key = openssl_pkey_get_private($credentials['private_key']);
    if (!$private_key) {
        return false;
    }
    
    openssl_sign($jwt_signing_input, $signature, $private_key, OPENSSL_ALGO_SHA256);
    $jwt = $jwt_signing_input . '.' . base64url_encode($signature);
    
    $token_request = [
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ];
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($token_request),
            'ignore_errors' => true
        ]
    ]);
    
    $response = @file_get_contents('https://oauth2.googleapis.com/token', false, $context);
    
    if ($response === false) {
        return false;
    }
    
    $token_data = json_decode($response, true);
    
    return isset($token_data['access_token']) ? $token_data['access_token'] : false;
}

function getParticipants() {
    global $spreadsheet_id, $sheet_name;
    
    $access_token = getAccessToken();
    if (!$access_token) {
        error_log("[ERROR] Не удалось получить токен доступа");
        return false;
    }
    
    $range = $sheet_name . '!A:O';
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}";
    
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ],
            'ignore_errors' => true
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        error_log("[ERROR] Не удалось получить данные из Google Sheets");
        return false;
    }
    
    $data = json_decode($response, true);
    
    if (!isset($data['values']) || count($data['values']) < 2) {
        return [];
    }
    
    // Пропускаем заголовок
    $participants = [];
    for ($i = 1; $i < count($data['values']); $i++) {
        $row = $data['values'][$i];
        // Обрабатываем строку даже если не все поля заполнены
        $participants[] = [
            'code' => isset($row[0]) ? $row[0] : '',
            'date' => isset($row[1]) ? $row[1] : '',
            'surname' => isset($row[2]) ? $row[2] : '',
            'name' => isset($row[3]) ? $row[3] : '',
            'patronymic' => isset($row[4]) ? $row[4] : '',
            'birthdate' => isset($row[5]) ? $row[5] : '',
            'city' => isset($row[6]) ? $row[6] : '',
            'phone' => isset($row[7]) ? $row[7] : '',
            'email' => isset($row[8]) ? $row[8] : '',
            'children' => isset($row[9]) ? $row[9] : '',
            'sup_count' => isset($row[10]) ? intval($row[10]) : 0,
            'sup_cost' => isset($row[11]) ? intval($row[11]) : 0,
            'payment_status' => isset($row[12]) ? $row[12] : '',
            'user_id' => isset($row[13]) ? $row[13] : '',
            'timestamp' => isset($row[14]) ? $row[14] : ''
        ];
    }
    
    return array_reverse($participants); // Последние сверху
}

$participants = getParticipants();

if ($participants === false) {
    die('Не удалось получить данные участников из Google Sheets.');
}
if (count($participants) === 0) {
    die('Нет зарегистрированных участников для выгрузки.');
}

// Используем классы PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Создаем новый Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Участники');

// Заголовки столбцов
$headers = [
    'A' => 'Код',
    'B' => 'Дата рег.',
    'C' => 'Фамилия',
    'D' => 'Имя',
    'E' => 'Отчество',
    'F' => 'Дата рождения',
    'G' => 'Город',
    'H' => 'Телефон',
    'I' => 'Email',
    'J' => 'Дети',
    'K' => 'Кол. SUP',
    'L' => 'Стоимость SUP',
    'M' => 'Оплата'
];

// Записываем заголовки
foreach ($headers as $col => $title) {
    $sheet->setCellValue($col . '1', $title);
}

// Заполняем данными
$rowNum = 2;
foreach ($participants as $p) {
    $sheet->setCellValue('A' . $rowNum, $p['code'] ?? '');
    $sheet->setCellValue('B' . $rowNum, $p['date'] ?? '');
    $sheet->setCellValue('C' . $rowNum, $p['surname'] ?? '');
    $sheet->setCellValue('D' . $rowNum, $p['name'] ?? '');
    $sheet->setCellValue('E' . $rowNum, $p['patronymic'] ?? '');
    $sheet->setCellValue('F' . $rowNum, $p['birthdate'] ?? '');
    $sheet->setCellValue('G' . $rowNum, $p['city'] ?? '');
    $sheet->setCellValue('H' . $rowNum, $p['phone'] ?? '');
    $sheet->setCellValue('I' . $rowNum, $p['email'] ?? '');
    $sheet->setCellValue('J' . $rowNum, $p['children'] ?? '');
    $sheet->setCellValue('K' . $rowNum, $p['sup_count'] ?? 0);
    $sheet->setCellValue('L' . $rowNum, $p['sup_cost'] ?? 0);
    $sheet->setCellValue('M' . $rowNum, $p['payment_status'] ?? '');
    $rowNum++;
}

// Устанавливаем стили для заголовков
$headerRange = 'A1:M1';
$sheet->getStyle($headerRange)->getFont()->setBold(true);
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

// Ширину столбцов "по содержимому"
foreach (range('A', 'M') as $columnID) {
    $sheet->getColumnDimension($columnID)->setAutoSize(true);
}

// Формируем имя файла
$filename = 'participants_' . date('Y-m-d_H-i-s') . '.xlsx';

// Заголовки для скачивания файла
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"$filename\"");
header('Cache-Control: max-age=0');

// Создаем объект Writer и отправляем вывод
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
