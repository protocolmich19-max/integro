<?php
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>#САПОТВОРЕНИЕ - Фестиваль САП-досок</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#52a66b',
                        secondary: '#b04f6d',
                        accent: '#c3c140',
                        water: '#8daad7',
                        sand: '#f5e4c5',
                    },
                    fontFamily: {
                        'montserrat': ['Montserrat', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .bg-gradient-festival {
                background: linear-gradient(to bottom, #c3c140 0%, #8daad7 50%, #2c7253 100%);
            }
        }
        body {
            font-family: 'Montserrat', sans-serif;
        }
        .wave {
            position: absolute;
            width: 100%;
            bottom: -5px;
            left: 0;
            z-index: 10;
        }
    </style>
</head>
<body class="bg-gray-50 overflow-x-hidden">
    <!-- Главный контейнер -->
    <div class="relative min-h-screen">
        <!-- Верхняя часть с фоном -->
        <div class="relative h-screen bg-gradient-festival overflow-hidden">
            <!-- Логотип и шапка -->
            <header class="container mx-auto px-4 py-6 flex justify-between items-center">
                <h1 class="text-white text-3xl md:text-4xl font-bold tracking-wide drop-shadow-lg">#САПОТВОРЕНИЕ</h1>
                <a href="#program" class="text-white bg-secondary hover:bg-opacity-90 font-medium rounded-full px-5 py-2 transition-all">ПРОГРАММА</a>
            </header>

            <!-- Центральный блок с информацией -->
            <div class="container mx-auto px-4 pt-8 pb-16 relative z-20">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Левая колонка с иллюстрацией -->
                    <div class="flex justify-center items-center">
                        <img src="https://ext.same-assets.com/1093247765/2716807989.gif" alt="САП-фестиваль" class="max-w-full h-auto rounded-lg shadow-lg">
                    </div>

                    <!-- Правая колонка с информацией -->
                    <div class="bg-white bg-opacity-90 p-6 rounded-lg shadow-lg">
                        <div class="flex flex-col space-y-4">
                            <div class="flex items-center space-x-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <p class="text-xl font-semibold">13.07.2025 09:30</p>
                            </div>
                            <div class="flex items-center space-x-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                                <p class="text-xl">г. Старый Оскол ВМЕСТЕ ПАРК <a href="https://clck.ru/3MJ5Ty" class="text-blue-600 hover:underline" target="_blank">Карта</a></p>
                            </div>
                            <p class="text-gray-700 mt-4">
                                Первый народный фестиваль #САПОТВОРЕНИЕ на сап-досках в Белгородской области.
                                Фестиваль обещает стать ярким событием, объединяющим любителей активного отдыха и ценителей русской культуры.
                            </p>
                            <div class="mt-6">
                                <a href="form.php" class="inline-block bg-secondary hover:bg-opacity-90 text-white text-xl font-bold py-3 px-8 rounded-full transition-all transform hover:scale-105">
                                    РЕГИСТРАЦИЯ
                                </a>
                                <p class="text-sm text-gray-500 mt-2">до 07.07.2025</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Волна внизу секции -->
            <div class="absolute bottom-0 left-0 w-full overflow-hidden">
                <svg class="wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
                    <path fill="#ffffff" fill-opacity="1" d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,170.7C960,160,1056,192,1152,197.3C1248,203,1344,181,1392,170.7L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                </svg>
            </div>
        </div>

        <!-- Раздел программы -->
        <section id="program" class="container mx-auto px-4 py-16">
            <h2 class="text-3xl md:text-4xl font-bold text-center mb-12 text-primary">ПРОГРАММА ФЕСТИВАЛЯ</h2>

            <div class="bg-white shadow-lg rounded-lg p-6 mb-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-primary bg-opacity-10 p-4 rounded-lg">
                        <h3 class="text-xl font-semibold text-primary mb-2">9:30 - 11:00</h3>
                        <p class="text-gray-700">Регистрация (приходите заранее, чтобы не было столпотворения 😉)</p>
                    </div>
                    <div class="bg-primary bg-opacity-10 p-4 rounded-lg">
                        <h3 class="text-xl font-semibold text-primary mb-2">11:00 - 13:00</h3>
                        <p class="text-gray-700">Мастер-классы по народному творчеству, управлению САП доской, САП-йога (запись на стойке регистрации)</p>
                    </div>
                    <div class="bg-primary bg-opacity-10 p-4 rounded-lg">
                        <h3 class="text-xl font-semibold text-primary mb-2">13:00 - 15:00</h3>
                        <p class="text-gray-700">Массовый заплыв на САПах в Белгородских национальных костюмах, в русско-народных костюмах</p>
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <div class="bg-primary bg-opacity-10 p-4 rounded-lg">
                        <h3 class="text-xl font-semibold text-primary mb-2">15:30 - 17:30</h3>
                        <p class="text-gray-700">Хороводы, САП-поло</p>
                    </div>
                    <div class="bg-primary bg-opacity-10 p-4 rounded-lg">
                        <h3 class="text-xl font-semibold text-primary mb-2">17:30</h3>
                        <p class="text-gray-700">Лотерея с призами от партнеров для участников в костюмах</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Раздел важной информации -->
        <section class="bg-gray-100 py-16">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl md:text-4xl font-bold text-center mb-12 text-primary">ВАЖНАЯ ИНФОРМАЦИЯ</h2>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="bg-white shadow-lg rounded-lg p-6">
                        <h3 class="text-xl font-semibold text-primary mb-4">ЧТО ВЗЯТЬ С СОБОЙ:</h3>
                        <ul class="list-disc list-inside space-y-2 text-gray-700">
                            <li>Запасные вещи</li>
                            <li>Головной убор</li>
                            <li>Очки</li>
                            <li>Крем от загара</li>
                            <li>Полотенце</li>
                            <li>Коврик/пляжный стул</li>
                            <li>Спасательный жилет (обязательно!)</li>
                            <li>Наличные деньги (интернет нестабильный)</li>
                        </ul>
                    </div>

                    <div class="bg-white shadow-lg rounded-lg p-6">
                        <h3 class="text-xl font-semibold text-secondary mb-4">ОБРАТИТЕ ВНИМАНИЕ:</h3>
                        <ul class="list-disc list-inside space-y-2 text-gray-700">
                            <li>Вход только по документам, удостоверяющим личность (паспорт, свидетельство о рождении)</li>
                            <li>Предусмотрен досмотр вещей каждого участника</li>
                            <li>Выход на воду только в спасательных жилетах!</li>
                            <li>Жилеты НЕ предоставляются - принести свои</li>
                            <li>Соблюдение правил безопасности на воде</li>
                            <li>Организаторы не обеспечивают участников САП досками и спасательными жилетами</li>
                        </ul>
                    </div>
                </div>

                <div class="mt-8 text-center">
                    <a href="form.php" class="inline-block bg-secondary hover:bg-opacity-90 text-white text-xl font-bold py-3 px-8 rounded-full transition-all transform hover:scale-105">
                        ЗАРЕГИСТРИРОВАТЬСЯ
                    </a>
                    <p class="text-sm text-gray-500 mt-2">Крайний срок регистрации - 07.07.2025 10:00</p>
                </div>
            </div>
        </section>

        <!-- Футер -->
        <footer class="bg-primary text-white py-8">
            <div class="container mx-auto px-4">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="mb-4 md:mb-0">
                        <h2 class="text-2xl font-bold">#САПОТВОРЕНИЕ</h2>
                        <p>Первый народный фестиваль на сап-досках в Белгородской области</p>
                    </div>

                    <div class="flex flex-col space-y-2">
                        <a href="https://telegra.ph/POLITIKA-OBRABOTKI-PERSONALNYH-DANNYH-03-25" class="hover:underline" target="_blank">Политика обработки персональных данных</a>
                        <a href="https://telegra.ph/POLITIKA-KONFIDENCIALNOSTI-I-POLZOVATELSKOE-SOGLASHENIE-03-25" class="hover:underline" target="_blank">Политика конфиденциальности</a>
                        <a href="https://telegra.ph/DOBROVOLNOE-SOGLASIE-I-OBYAZATELSTVA-UCHASTNIKA-05-27" class="hover:underline" target="_blank">Правила участия</a>
                    </div>
                </div>

                <div class="border-t border-white border-opacity-20 mt-6 pt-6 text-center">
                    <p>&copy; 2025 #САПОТВОРЕНИЕ. Все права защищены.</p>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>
