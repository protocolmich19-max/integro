<?php
// Функции обработки данных формы и интеграция с Google Sheets

function generateRegistrationCode() {
    // Генерация уникального кода регистрации в формате F48-1-XXXXXXXXX
    $prefix = 'F48-1-';
    $uniqueId = time() . rand(100, 999);
    return $prefix . $uniqueId;
}

function validateForm($data) {
    $errors = [];

    // Проверка имени
    if (empty($data['name']) || strlen($data['name']) < 2) {
        $errors['name'] = 'Имя должно содержать минимум 2 символа';
    }

    // Проверка фамилии
    if (empty($data['surname']) || strlen($data['surname']) < 2) {
        $errors['surname'] = 'Фамилия должна содержать минимум 2 символа';
    }

    // Проверка города
    if (empty($data['city']) || strlen($data['city']) < 2) {
        $errors['city'] = 'Название города должно содержать минимум 2 символа';
    }

    // Проверка даты рождения
    if (empty($data['birthdate'])) {
        $errors['birthdate'] = 'Пожалуйста, укажите дату рождения';
    } else {
        $birthdate = strtotime($data['birthdate']);
        $currentDate = time();
        $age = floor(($currentDate - $birthdate) / (365 * 24 * 60 * 60));

        if ($birthdate > $currentDate) {
            $errors['birthdate'] = 'Дата рождения не может быть в будущем';
        } elseif ($age > 120) {
            $errors['birthdate'] = 'Возраст не может превышать 120 лет';
        }
    }

    // Проверка телефона
    if (empty($data['phone'])) {
        $errors['phone'] = 'Пожалуйста, укажите номер телефона';
    } elseif (!preg_match('/^\+7\d{10}$/', $data['phone'])) {
        $errors['phone'] = 'Номер телефона должен быть в формате +7XXXXXXXXXX';
    }

    // Проверка email
    if (empty($data['email'])) {
        $errors['email'] = 'Пожалуйста, укажите email';
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Пожалуйста, укажите корректный email';
    }

    // Проверка детей, если есть
    if (!empty($data['children'])) {
        if (count($data['children']) > 3) {
            $errors['children'] = 'Максимальное количество детей - 3';
        } else {
            foreach ($data['children'] as $index => $child) {
                if (empty($child['full_name']) || strlen($child['full_name']) < 5) {
                    $errors["child_name_$index"] = 'ФИО ребенка должно содержать минимум 5 символов';
                }

                if (empty($child['birth_date'])) {
                    $errors["child_birthdate_$index"] = 'Пожалуйста, укажите дату рождения ребенка';
                } else {
                    $childBirthdate = strtotime($child['birth_date']);
                    $currentDate = time();
                    $childAge = floor(($currentDate - $childBirthdate) / (365 * 24 * 60 * 60));

                    if ($childBirthdate > $currentDate) {
                        $errors["child_birthdate_$index"] = 'Дата рождения не может быть в будущем';
                    } elseif ($childAge > 18) {
                        $errors["child_birthdate_$index"] = 'Возраст ребенка не может превышать 18 лет';
                    }
                }
            }
        }
    }

    // Проверка согласий
    if (empty($data['agreements'])) {
        $errors['agreements'] = 'Необходимо принять все обязательные соглашения';
    }

    return $errors;
}

function calculateSapRentalCost($quantity) {
    // Расчет стоимости аренды САП-досок
    $pricePerSap = 600; // Цена за одну доску
    return $quantity * $pricePerSap;
}

/**
 * Отправляет данные в Google Sheets с использованием сервисного аккаунта
 * @param array $rowData Массив данных для записи в таблицу
 * @return bool Результат операции
 */
function sendToGoogleSheets($rowData) {
    try {
        // Путь к файлу сервисного аккаунта
        $serviceAccountFile = __DIR__ . '/service-account.json';

        // Проверяем наличие файла
        if (!file_exists($serviceAccountFile)) {
            error_log('Файл сервисного аккаунта не найден: ' . $serviceAccountFile);
            return false;
        }

        // Получаем содержимое файла сервисного аккаунта
        $serviceAccountJson = file_get_contents($serviceAccountFile);
        if (!$serviceAccountJson) {
            error_log('Не удалось прочитать файл сервисного аккаунта');
            return false;
        }

        // Декодируем JSON сервисного аккаунта
        $serviceAccount = json_decode($serviceAccountJson, true);
        if (!$serviceAccount) {
            error_log('Не удалось декодировать JSON сервисного аккаунта');
            return false;
        }

        // ID Google Таблицы (замените на ваш ID)
        $spreadsheetId = $serviceAccount['spreadsheet_id'] ?? '';

        // Если ID таблицы не указан в service-account.json, используем значение по умолчанию
        if (empty($spreadsheetId)) {
            // Значение по умолчанию (замените на ваш ID таблицы)
            $spreadsheetId = '1Yfv-LXKkr8iu95n5EGfFD0lZ7VWsZ_KFY_3hGyCpQzA';
        }

        // Имя листа в таблице
        $sheetName = 'Регистрации';

        // Формируем URL для API
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheetId}/values/{$sheetName}:append?valueInputOption=RAW";

        // Подготавливаем JWT токен для авторизации
        $now = time();
        $jwt = [
            'iss' => $serviceAccount['client_email'],
            'scope' => 'https://www.googleapis.com/auth/spreadsheets',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        // Кодируем JWT в base64
        $jwtHeader = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
        $jwtClaim = base64_encode(json_encode($jwt));
        $jwtHeaderClaim = $jwtHeader . '.' . $jwtClaim;

        // Подписываем JWT приватным ключом
        $privateKey = $serviceAccount['private_key'];
        openssl_sign($jwtHeaderClaim, $signature, $privateKey, OPENSSL_ALGO_SHA256);
        $jwtSignature = base64_encode($signature);

        // Формируем полный JWT токен
        $jwtToken = $jwtHeaderClaim . '.' . $jwtSignature;

        // Получаем access token с помощью JWT
        $tokenUrl = 'https://oauth2.googleapis.com/token';
        $tokenData = [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwtToken
        ];

        // Инициализируем curl для получения токена
        $tokenCh = curl_init($tokenUrl);
        curl_setopt($tokenCh, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($tokenCh, CURLOPT_POSTFIELDS, http_build_query($tokenData));
        curl_setopt($tokenCh, CURLOPT_POST, true);

        $tokenResponse = curl_exec($tokenCh);
        $tokenHttpCode = curl_getinfo($tokenCh, CURLINFO_HTTP_CODE);
        curl_close($tokenCh);

        if ($tokenHttpCode != 200) {
            error_log('Не удалось получить access token: ' . $tokenResponse);
            return false;
        }

        $tokenData = json_decode($tokenResponse, true);
        $accessToken = $tokenData['access_token'];

        // Подготавливаем данные для отправки в таблицу
        $values = [
            'values' => [$rowData]
        ];

        // Инициализируем curl для отправки данных в таблицу
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($values));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            return true;
        } else {
            error_log('Ошибка при отправке данных в Google Sheets: ' . $response);
            return false;
        }
    } catch (Exception $e) {
        error_log('Исключение при отправке данных в Google Sheets: ' . $e->getMessage());
        return false;
    }
}

function saveRegistration($data) {
    // Подготовка данных регистрации
    $registrationCode = generateRegistrationCode();
    $registrationDate = date('d.m.Y H:i');
    $sapRentalCost = calculateSapRentalCost($data['sap_rental_quantity'] ?? 0);

    $registrationData = [
        'surname' => $data['surname'],
        'name' => $data['name'],
        'patronymic' => $data['patronymic'] ?? 'нет',
        'birthdate' => $data['birthdate'],
        'city' => $data['city'],
        'phone' => $data['phone'],
        'email' => $data['email'],
        'children' => $data['children'] ?? [],
        'sap_rental_quantity' => $data['sap_rental_quantity'] ?? 0,
        'sap_rental_cost' => $sapRentalCost,
        'festival_id' => 'SAPO2025',
        'registration_code' => $registrationCode,
        'registration_date' => $registrationDate,
        'payment_status' => 'paid', // Для демонстрации считаем оплаченным
        'user_id' => 'USER_' . rand(1000, 9999)
    ];

    // Подготовка данных детей
    $childrenData = '';
    if (!empty($data['children'])) {
        foreach ($data['children'] as $child) {
            $childrenData .= $child['full_name'] . ' (' . $child['birth_date'] . '); ';
        }
        $childrenData = rtrim($childrenData, '; ');
    }

    // Подготовка данных о согласиях
    $agreements = implode(', ', $data['agreements'] ?? []);

    // Подготовка данных для отправки в Google Sheets
    $rowData = [
        $registrationData['registration_code'],       // Код регистрации
        $registrationData['registration_date'],       // Дата регистрации
        $registrationData['surname'],                 // Фамилия
        $registrationData['name'],                    // Имя
        $registrationData['patronymic'],              // Отчество
        $registrationData['birthdate'],               // Дата рождения
        $registrationData['city'],                    // Город
        $registrationData['phone'],                   // Телефон
        $registrationData['email'],                   // Email
        $childrenData,                                // Данные о детях
        $registrationData['sap_rental_quantity'],     // Количество САП-досок
        $registrationData['sap_rental_cost'],         // Стоимость аренды
        $agreements,                                  // Согласия
        $registrationData['payment_status'],          // Статус оплаты
        date('Y-m-d H:i:s')                          // Время записи
    ];

    // Отправка данных в Google Sheets
    $sheetResult = sendToGoogleSheets($rowData);

    // Запись лога результата
    if ($sheetResult) {
        error_log("Успешно записаны данные в Google Sheets для " . $registrationData['email']);
    } else {
        error_log("Ошибка при записи данных в Google Sheets для " . $registrationData['email']);
        // Установка флага ошибки Google Sheets
        if (!isset($_SESSION)) {
            session_start();
        }
        $_SESSION['sheet_error'] = true;
        // Записываем детальную информацию об ошибке в лог-файл
        logError("Ошибка записи в Google Sheets для " . $registrationData['email'] . ". Код: " . $registrationCode);
    }

    // Сохранение в сессию для отображения на странице подтверждения
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION['registration'] = $registrationData;

    return $registrationData;
}

// Функция для логирования ошибок в файл
function logError($message) {
    $logFile = __DIR__ . '/error.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}
?>
