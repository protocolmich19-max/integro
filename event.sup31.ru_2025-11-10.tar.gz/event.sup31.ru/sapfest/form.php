<?php
require_once 'functions.php';

// Инициализация переменных для результатов регистрации
$errors = [];
$registrationData = null;
$registrationSuccess = false;

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Проверка и обработка формы
    $formData = [
        'surname' => $_POST['surname'] ?? '',
        'name' => $_POST['name'] ?? '',
        'patronymic' => $_POST['patronymic'] ?? '',
        'birthdate' => $_POST['birthdate'] ?? '',
        'city' => $_POST['city'] ?? '',
        'phone' => $_POST['phone'] ?? '',
        'email' => $_POST['email'] ?? '',
        'sap_rental_quantity' => (int)($_POST['sap_rental_quantity'] ?? 0),
        'agreements' => isset($_POST['agreements']) ? $_POST['agreements'] : []
    ];

    // Обработка данных о детях
    $formData['children'] = [];
    if (isset($_POST['child_name']) && is_array($_POST['child_name'])) {
        foreach ($_POST['child_name'] as $index => $name) {
            if (!empty($name)) {
                $formData['children'][] = [
                    'full_name' => $name,
                    'birth_date' => $_POST['child_birthdate'][$index] ?? ''
                ];
            }
        }
    }

    // Валидация формы
    $errors = validateForm($formData);

    // Если ошибок нет, сохраняем регистрацию
    if (empty($errors)) {
        $registrationData = saveRegistration($formData);
        $registrationSuccess = true;
    }
}

// Установка сессии, если еще не установлена
if (!isset($_SESSION)) {
    session_start();
}

// Если есть успешная регистрация в сессии и это не отправка формы, получаем данные
if (!$registrationSuccess && isset($_SESSION['registration'])) {
    $registrationData = $_SESSION['registration'];
    $registrationSuccess = true;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация на фестиваль #САПОТВОРЕНИЕ</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#52a66b',
                        secondary: '#b04f6d',
                        accent: '#c3c140',
                        water: '#8daad7',
                        sand: '#f5e4c5',
                    },
                    fontFamily: {
                        'montserrat': ['Montserrat', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .bg-gradient-festival {
                background: linear-gradient(to bottom, #c3c140 0%, #8daad7 50%, #2c7253 100%);
            }
        }
        body {
            font-family: 'Montserrat', sans-serif;
        }
        /* Стили для инпутов */
        .form-input {
            @apply w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent;
        }
        .form-label {
            @apply block text-gray-700 font-medium mb-1;
        }
        .form-error {
            @apply text-red-500 text-sm mt-1;
        }
        /* Стили для чекбоксов */
        .custom-checkbox {
            @apply appearance-none h-5 w-5 border border-gray-300 rounded-md bg-white checked:bg-primary checked:border-transparent focus:outline-none focus:ring-2 focus:ring-primary cursor-pointer relative;
        }
        .custom-checkbox:checked {
            background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Шапка -->
    <header class="bg-primary text-white py-4 shadow-md">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center">
                <a href="index.php" class="text-2xl font-bold tracking-wide">#САПОТВОРЕНИЕ</a>
                <a href="index.php" class="bg-white text-primary hover:bg-gray-100 font-medium rounded-full px-5 py-2 transition-all">
                    На главную
                </a>
            </div>
        </div>
    </header>

    <!-- Основной контент -->
    <main class="container mx-auto px-4 py-8">
        <?php if ($registrationSuccess && $registrationData): ?>
            <!-- Результат успешной регистрации -->
            <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-8 my-8">
                <div class="text-center mb-8">
                    <div class="inline-block bg-green-100 rounded-full p-4 mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    <h1 class="text-3xl font-bold text-primary">✅ Вы зарегистрированы на этот фестиваль!</h1>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div>
                        <h2 class="text-xl font-semibold mb-4">Данные участника:</h2>
                        <div class="space-y-2">
                            <p><span class="font-medium">ФИО:</span> <?php echo htmlspecialchars($registrationData['surname'] . ' ' . $registrationData['name'] . ' ' . $registrationData['patronymic']); ?></p>
                            <p><span class="font-medium">Дата рождения:</span> <?php echo htmlspecialchars($registrationData['birthdate']); ?></p>
                            <p><span class="font-medium">Город:</span> <?php echo htmlspecialchars($registrationData['city']); ?></p>
                            <p><span class="font-medium">Телефон:</span> <?php echo htmlspecialchars($registrationData['phone']); ?></p>
                            <p><span class="font-medium">Email:</span> <?php echo htmlspecialchars($registrationData['email']); ?></p>
                        </div>
                    </div>

                    <div>
                        <h2 class="text-xl font-semibold mb-4">Информация о регистрации:</h2>
                        <div class="space-y-2">
                            <p><span class="font-medium">📋 Регистрация:</span> <?php echo htmlspecialchars($registrationData['registration_date']); ?></p>
                            <p><span class="font-medium">🆔 Ваш код:</span> <?php echo htmlspecialchars($registrationData['registration_code']); ?></p>
                            <p><span class="font-medium">💳 Статус оплаты:</span> ✅ Оплачено</p>
                            <?php if ($registrationData['sap_rental_quantity'] > 0): ?>
                                <p><span class="font-medium">🏄 САП-доски:</span> <?php echo $registrationData['sap_rental_quantity']; ?> шт.</p>
                                <p><span class="font-medium">💰 Стоимость аренды:</span> <?php echo $registrationData['sap_rental_cost']; ?> ₽</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php if (!empty($registrationData['children'])): ?>
                    <div class="mb-8">
                        <h2 class="text-xl font-semibold mb-4">Информация о детях:</h2>
                        <div class="space-y-2">
                            <?php foreach($registrationData['children'] as $child): ?>
                                <p>• <?php echo htmlspecialchars($child['full_name']); ?>, <?php echo htmlspecialchars($child['birth_date']); ?></p>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="text-center">
                    <a href="form.php" class="bg-secondary hover:bg-opacity-90 text-white font-bold py-3 px-8 rounded-full inline-block">
                        Зарегистрироваться ещё раз
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Форма регистрации -->
            <div class="max-w-4xl mx-auto">
                <h1 class="text-3xl font-bold text-center text-primary mb-8">Регистрация на фестиваль #САПОТВОРЕНИЕ</h1>

                <form action="form.php" method="post" class="bg-white rounded-lg shadow-lg p-8">
                    <?php if (!empty($errors) && is_array($errors)): ?>
                        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
                            <p class="font-bold">Пожалуйста, исправьте ошибки в форме:</p>
                            <ul class="list-disc list-inside mt-2">
                                <?php foreach($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['sheet_error']) && $_SESSION['sheet_error']): ?>
                        <div class="bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded mb-6">
                            <p class="font-bold">Внимание!</p>
                            <p>Возникла проблема при сохранении данных в Google Таблицу. Администратор будет уведомлен. Ваша регистрация все равно будет обработана.</p>
                            <?php unset($_SESSION['sheet_error']); ?>
                        </div>
                    <?php endif; ?>

                    <div class="mb-8">
                        <h2 class="text-xl font-semibold mb-4 text-primary">Основные данные участника</h2>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="form-label" for="surname">Фамилия <span class="text-red-500">*</span></label>
                                <input type="text" id="surname" name="surname" class="form-input" value="<?php echo htmlspecialchars($_POST['surname'] ?? ''); ?>" required>
                                <?php if (isset($errors['surname'])): ?>
                                    <p class="form-error"><?php echo htmlspecialchars($errors['surname']); ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label class="form-label" for="name">Имя <span class="text-red-500">*</span></label>
                                <input type="text" id="name" name="name" class="form-input" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                                <?php if (isset($errors['name'])): ?>
                                    <p class="form-error"><?php echo htmlspecialchars($errors['name']); ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label class="form-label" for="patronymic">Отчество</label>
                                <input type="text" id="patronymic" name="patronymic" class="form-input" value="<?php echo htmlspecialchars($_POST['patronymic'] ?? ''); ?>" placeholder="Если нет, напишите 'нет'">
                            </div>

                            <div>
                                <label class="form-label" for="birthdate">Дата рождения <span class="text-red-500">*</span></label>
                                <input type="date" id="birthdate" name="birthdate" class="form-input" value="<?php echo htmlspecialchars($_POST['birthdate'] ?? ''); ?>" required>
                                <?php if (isset($errors['birthdate'])): ?>
                                    <p class="form-error"><?php echo htmlspecialchars($errors['birthdate']); ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label class="form-label" for="city">Город проживания <span class="text-red-500">*</span></label>
                                <input type="text" id="city" name="city" class="form-input" value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>" required>
                                <?php if (isset($errors['city'])): ?>
                                    <p class="form-error"><?php echo htmlspecialchars($errors['city']); ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label class="form-label" for="phone">Номер телефона <span class="text-red-500">*</span></label>
                                <input type="tel" id="phone" name="phone" class="form-input" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" placeholder="+7XXXXXXXXXX" required>
                                <?php if (isset($errors['phone'])): ?>
                                    <p class="form-error"><?php echo htmlspecialchars($errors['phone']); ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label class="form-label" for="email">Email <span class="text-red-500">*</span></label>
                                <input type="email" id="email" name="email" class="form-input" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                                <?php if (isset($errors['email'])): ?>
                                    <p class="form-error"><?php echo htmlspecialchars($errors['email']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="mb-8">
                        <h2 class="text-xl font-semibold mb-4 text-primary">Данные о детях (опционально)</h2>
                        <p class="text-gray-600 mb-4">Вы можете добавить до 3 детей</p>

                        <div id="children-container">
                            <!-- Шаблон для добавления ребенка -->
                            <div class="child-entry border border-gray-200 rounded-lg p-4 mb-4">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="form-label" for="child_name_0">ФИО ребенка</label>
                                        <input type="text" id="child_name_0" name="child_name[]" class="form-input" value="<?php echo htmlspecialchars($_POST['child_name'][0] ?? ''); ?>">
                                    </div>

                                    <div>
                                        <label class="form-label" for="child_birthdate_0">Дата рождения ребенка</label>
                                        <input type="date" id="child_birthdate_0" name="child_birthdate[]" class="form-input" value="<?php echo htmlspecialchars($_POST['child_birthdate'][0] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button type="button" id="add-child" class="mt-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg transition-all">
                            + Добавить ребенка
                        </button>
                    </div>

                    <div class="mb-8">
                        <h2 class="text-xl font-semibold mb-4 text-primary">Аренда САП-досок</h2>

                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                            <div class="flex items-start">
                                <div class="text-blue-500 mr-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                </div>
                                <p class="text-blue-700">Вы можете арендовать САП-доски для участия в фестивале. Стоимость аренды одной САП-доски: 600 ₽.</p>
                            </div>
                        </div>

                        <div>
                            <label class="form-label" for="sap_rental_quantity">Количество САП-досок для аренды</label>
                            <select id="sap_rental_quantity" name="sap_rental_quantity" class="form-input">
                                <option value="0" <?php echo (isset($_POST['sap_rental_quantity']) && $_POST['sap_rental_quantity'] == 0) ? 'selected' : ''; ?>>Не нужно арендовать</option>
                                <?php for($i=1; $i<=5; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo (isset($_POST['sap_rental_quantity']) && $_POST['sap_rental_quantity'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?> шт.</option>
                                <?php endfor; ?>
                            </select>
                            <p class="text-sm text-gray-600 mt-1">Максимальное количество досок для аренды: 5 шт.</p>
                        </div>
                    </div>

                    <div class="mb-8">
                        <h2 class="text-xl font-semibold mb-4 text-primary">Соглашения и правила участия</h2>

                        <div class="space-y-4">
                            <div class="flex items-start">
                                <div class="flex items-center h-5 mt-1">
                                    <input type="checkbox" id="agreement_1" name="agreements[]" value="personal_data" class="custom-checkbox" <?php echo (isset($_POST['agreements']) && in_array('personal_data', $_POST['agreements'])) ? 'checked' : ''; ?> required>
                                </div>
                                <label for="agreement_1" class="ml-3 text-gray-700">
                                    Я согласен на <a href="https://telegra.ph/POLITIKA-OBRABOTKI-PERSONALNYH-DANNYH-03-25" class="text-blue-600 hover:underline" target="_blank">обработку персональных данных</a> <span class="text-red-500">*</span>
                                </label>
                            </div>

                            <div class="flex items-start">
                                <div class="flex items-center h-5 mt-1">
                                    <input type="checkbox" id="agreement_2" name="agreements[]" value="privacy_policy" class="custom-checkbox" <?php echo (isset($_POST['agreements']) && in_array('privacy_policy', $_POST['agreements'])) ? 'checked' : ''; ?> required>
                                </div>
                                <label for="agreement_2" class="ml-3 text-gray-700">
                                    Я ознакомлен с <a href="https://telegra.ph/POLITIKA-KONFIDENCIALNOSTI-I-POLZOVATELSKOE-SOGLASHENIE-03-25" class="text-blue-600 hover:underline" target="_blank">Политикой конфиденциальности</a> <span class="text-red-500">*</span>
                                </label>
                            </div>

                            <div class="flex items-start">
                                <div class="flex items-center h-5 mt-1">
                                    <input type="checkbox" id="agreement_3" name="agreements[]" value="participation_rules" class="custom-checkbox" <?php echo (isset($_POST['agreements']) && in_array('participation_rules', $_POST['agreements'])) ? 'checked' : ''; ?> required>
                                </div>
                                <label for="agreement_3" class="ml-3 text-gray-700">
                                    Я ознакомлен с <a href="https://telegra.ph/DOBROVOLNOE-SOGLASIE-I-OBYAZATELSTVA-UCHASTNIKA-05-27" class="text-blue-600 hover:underline" target="_blank">правилами участия</a> <span class="text-red-500">*</span>
                                </label>
                            </div>

                            <div class="flex items-start">
                                <div class="flex items-center h-5 mt-1">
                                    <input type="checkbox" id="agreement_4" name="agreements[]" value="safety_rules" class="custom-checkbox" <?php echo (isset($_POST['agreements']) && in_array('safety_rules', $_POST['agreements'])) ? 'checked' : ''; ?> required>
                                </div>
                                <label for="agreement_4" class="ml-3 text-gray-700">
                                    Я обязуюсь выходить на воду только в спасательном жилете и соблюдать правила безопасности на воде <span class="text-red-500">*</span>
                                </label>
                            </div>

                            <?php if (isset($errors['agreements'])): ?>
                                <p class="form-error"><?php echo htmlspecialchars($errors['agreements']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div class="flex items-start">
                            <div class="text-blue-500 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                            <p class="text-blue-700">Ваши данные будут сохранены в защищенной Google Таблице. Мы обрабатываем информацию в соответствии с политикой конфиденциальности.</p>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="bg-secondary hover:bg-opacity-90 text-white text-xl font-bold py-3 px-8 rounded-full transition-all transform hover:scale-105">
                            Зарегистрироваться
                        </button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </main>

    <!-- Футер -->
    <footer class="bg-primary text-white py-6 mt-16">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; 2025 #САПОТВОРЕНИЕ. Все права защищены.</p>
            <div class="mt-2">
                <a href="https://telegra.ph/POLITIKA-OBRABOTKI-PERSONALNYH-DANNYH-03-25" class="text-white hover:underline mx-2" target="_blank">Политика обработки персональных данных</a>
                <a href="https://telegra.ph/POLITIKA-KONFIDENCIALNOSTI-I-POLZOVATELSKOE-SOGLASHENIE-03-25" class="text-white hover:underline mx-2" target="_blank">Политика конфиденциальности</a>
            </div>
        </div>
    </footer>

    <!-- JavaScript для добавления детей -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const childrenContainer = document.getElementById('children-container');
            const addChildButton = document.getElementById('add-child');
            let childCount = 1; // Начинаем с 1, так как первый ребенок уже есть в шаблоне

            addChildButton.addEventListener('click', function() {
                if (childCount < 3) {
                    const childEntry = document.createElement('div');
                    childEntry.className = 'child-entry border border-gray-200 rounded-lg p-4 mb-4';
                    childEntry.innerHTML = `
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="form-label" for="child_name_${childCount}">ФИО ребенка</label>
                                <input type="text" id="child_name_${childCount}" name="child_name[]" class="form-input">
                            </div>

                            <div>
                                <label class="form-label" for="child_birthdate_${childCount}">Дата рождения ребенка</label>
                                <input type="date" id="child_birthdate_${childCount}" name="child_birthdate[]" class="form-input">
                            </div>
                        </div>
                        <button type="button" class="remove-child mt-2 text-red-500 hover:text-red-700">Удалить</button>
                    `;

                    childrenContainer.appendChild(childEntry);
                    childCount++;

                    // Если достигли максимума, скрываем кнопку
                    if (childCount >= 3) {
                        addChildButton.style.display = 'none';
                    }

                    // Добавляем обработчик для кнопки удаления
                    const removeButton = childEntry.querySelector('.remove-child');
                    removeButton.addEventListener('click', function() {
                        childrenContainer.removeChild(childEntry);
                        childCount--;

                        // Показываем кнопку, если меньше максимума
                        if (childCount < 3) {
                            addChildButton.style.display = 'block';
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
