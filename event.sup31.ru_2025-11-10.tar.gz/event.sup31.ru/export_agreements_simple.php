<?php
require_once 'view_logs.php';

// Получаем участников
$participants = getParticipants();

if ($participants === false || count($participants) === 0) {
    die('Нет участников для генерации соглашений');
}

// Создаем временную папку для документов
$temp_dir = 'temp_agreements_' . date('YmdHis');
if (!mkdir($temp_dir)) {
    die('Не удалось создать временную папку');
}

// Генерируем HTML документ для каждого участника
foreach ($participants as $index => $participant) {
    $fio = trim($participant['surname'] . ' ' . $participant['name'] . ' ' . $participant['patronymic']);
    if (empty($fio)) {
        $fio = '______________________________';
    }
    
    $birthdate = !empty($participant['birthdate']) ? $participant['birthdate'] : '____________';
    $city = !empty($participant['city']) ? $participant['city'] : '____________';
    $phone = !empty($participant['phone']) ? $participant['phone'] : '____________';
    
    $html = '<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Соглашение - ' . htmlspecialchars($fio) . '</title>
    <style>
        @page { size: A4; margin: 2cm; }
        body { font-family: "Times New Roman", Times, serif; font-size: 12pt; line-height: 1.5; }
        h1 { text-align: center; font-size: 16pt; margin: 20px 0; }
        h2 { text-align: center; font-size: 14pt; margin: 15px 0; }
        h3 { font-size: 12pt; margin: 15px 0 10px 0; }
        p { margin: 10px 0; text-align: justify; }
        .participant-info { font-weight: bold; margin: 20px 0; }
        .signature { margin-top: 50px; }
        .children-list { margin-left: 20px; }
        @media print { body { margin: 0; } }
    </style>
</head>
<body>
    <h1>ДОБРОВОЛЬНОЕ СОГЛАСИЕ И ОБЯЗАТЕЛЬСТВА УЧАСТНИКА</h1>
    <h2>МЕРОПРИЯТИЯ НА ВОДЕ НА САП ДОСКАХ</h2>
    <h2>ПРАВИЛА ПОВЕДЕНИЯ И ТЕХНИКА БЕЗОПАСНОСТИ</h2>
    
    <div class="participant-info">
        <p>Я, ' . htmlspecialchars($fio) . ',<br>
        <small>(ФИО полностью)</small></p>
        
        <p>дата рождения: ' . htmlspecialchars($birthdate) . ', город проживания: ' . htmlspecialchars($city) . ', контактный телефон: ' . htmlspecialchars($phone) . ',</p>
        
        <p>добровольно и осознанно подтверждаю свое согласие на участие в мероприятии на воде на САП досках, проводимом САП Клубом «ПриПраВа®», и обязуюсь соблюдать следующие правила:</p>
    </div>
    
    <h3>1. ОБЩИЕ ПОЛОЖЕНИЯ</h3>
    <p>1.1. Настоящее соглашение регулирует отношения между участником (мной) и организатором – клуб ПриПраВа® в рамках фестиваля.</p>
    <p>1.2. Организатор оставляет за собой право изменять программу мероприятия, зоны проведения и другие условия в случае форс-мажорных обстоятельств.</p>
    
    <h3>2. ОТВЕТСТВЕННОСТЬ УЧАСТНИКА</h3>
    <p>2.1. Я осознаю риски, связанные с участием в активностях на воде, и принимаю полную ответственность за:</p>
    <p>- свою жизнь и здоровье;</p>
    <p>- жизнь и здоровье несовершеннолетних детей, находящихся под моей опекой:</p>
    <div class="children-list">';
    
    if (!empty($participant['children'])) {
        $children = explode(',', $participant['children']);
        foreach ($children as $child) {
            $child = trim($child);
            if (!empty($child)) {
                $html .= '<p>• ФИО и дата рождения ребенка: ' . htmlspecialchars($child) . '</p>';
            }
        }
    } else {
        $html .= '<p>• ФИО и дата рождения ребенка: __________________________________</p>';
        $html .= '<p>• ФИО и дата рождения ребенка: __________________________________</p>';
        $html .= '<p>• ФИО и дата рождения ребенка: __________________________________</p>';
    }
    
    $html .= '</div>
    <p>2.2. В случае аренды оборудования обязуюсь:</p>
    <p>- возместить стоимость повреждения или утери по ценам закупки на дату ущерба;</p>
    <p>- следовать инструкциям по эксплуатации.</p>
    
    <h3>3. ТРЕБОВАНИЯ К УЧАСТНИКУ</h3>
    <p>3.1. Я подтверждаю, что:</p>
    <p>- не имею медицинских противопоказаний к физическим нагрузкам;</p>
    <p>- умею плавать;</p>
    <p>- не нахожусь в состоянии алкогольного/наркотического опьянения.</p>
    <p>3.2. Обязуюсь:</p>
    <p>- использовать спасательный жилет и лиш (не снимать их на воде);</p>
    <p>- не заходить в зоны купания или движения моторных судов;</p>
    <p>- следовать указаниям организаторов.</p>
    
    <h3>4. БЕЗОПАСНОСТЬ И ФОРС-МАЖОР</h3>
    <p>4.1. В случае ЧС обязуюсь следовать указаниям спасателей или ГО ЧС.</p>
    <p>4.2. Организатор не несет ответственности за:</p>
    <p>- утерю/повреждение личных вещей;</p>
    <p>- травмы, полученные из-за нарушения правил участником.</p>
    
    <h3>5. ИСПОЛЬЗОВАНИЕ ПЕРСОНАЛЬНЫХ ДАННЫХ И МЕДИA</h3>
    <p>5.1. Даю согласие на обработку моих персональных данных в рамках мероприятия.</p>
    <p>5.2. Разрешаю использование моего изображения в рекламных материалах без компенсации.</p>
    
    <h3>6. ПРОЧИЕ УСЛОВИЯ</h3>
    <p>6.1. Нарушение правил влечет удаление с мероприятия без компенсации.</p>
    <p>6.2. Вход на территорию — только при предъявлении паспорта, свидетельства о рождения для несовершеннолетних.</p>
    
    <div class="signature">
        <p>Дата: __________' . date('Y') . 'г. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Подпись: ___________________</p>
    </div>
    
    <div style="margin-top: 30px;">
        <p><strong>Организатор:</strong><br>
        САП Клуб «ПриПраВа®»<br>
        Контактный телефон: 8-910-322-64-40<br>
        Email: priprava31@gmail.com</p>
    </div>
</body>
</html>';
    
    // Сохраняем HTML файл
    $surname = !empty($participant['surname']) ? $participant['surname'] : 'Participant_' . ($index + 1);
    $filename = 'Согласие_' . $surname . '_' . $participant['code'] . '.html';
    $filename = preg_replace('/[^a-zA-Zа-яА-Я0-9_\-\.]/', '_', $filename);
    
    file_put_contents($temp_dir . '/' . $filename, $html);
}

// Создаем ZIP архив
$zip_filename = 'agreements_' . date('Y-m-d_H-i-s') . '.zip';
$zip = new ZipArchive();

if ($zip->open($zip_filename, ZipArchive::CREATE) === TRUE) {
    // Добавляем все файлы из временной папки
    $files = glob($temp_dir . '/*.html');
    foreach ($files as $file) {
        $zip->addFile($file, basename($file));
    }
    $zip->close();
    
    // Удаляем временные файлы
    foreach ($files as $file) {
        unlink($file);
    }
    rmdir($temp_dir);
    
    // Отправляем ZIP файл
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
    header('Content-Length: ' . filesize($zip_filename));
    readfile($zip_filename);
    
    // Удаляем ZIP файл после отправки
    unlink($zip_filename);
    exit;
} else {
    die('Не удалось создать ZIP архив. Убедитесь, что расширение ZIP включено в PHP.');
}
?>
