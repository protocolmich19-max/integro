<?php
header('Content-Type: text/html; charset=utf-8');
header('Content-Disposition: attachment; filename="agreements_' . date('Y-m-d_H-i-s') . '.html"');

require_once 'view_logs.php';

$participants = getParticipants();

if ($participants === false || count($participants) === 0) {
    echo "<h1>Нет данных для выгрузки соглашений</h1>";
    exit;
}

echo "<!DOCTYPE html><html lang='ru'><head><meta charset='UTF-8'><title>Соглашения участников</title></head><body>";
echo "<h1>Соглашения участников фестиваля САПОТВОРЕНИЕ</h1>";
echo "<p>Дата выгрузки: " . date('Y-m-d H:i:s') . "</p>";
echo "<hr>";

foreach ($participants as $p) {
    $fio = trim($p['surname'] . ' ' . $p['name'] . ' ' . $p['patronymic']);
    echo "<h2>Участник: " . htmlspecialchars($fio ?: '-') . "</h2>";
    echo "<p>ID пользователя: " . htmlspecialchars($p['user_id'] ?: '-') . "</p>";
    echo "<p>Дата регистрации: " . htmlspecialchars($p['date'] ?: '-') . "</p>";
    echo "<p>Статус оплаты: " . htmlspecialchars($p['payment_status'] ?: '-') . "</p>";
    echo "<p>Соглашение: <em>Здесь может быть текст соглашения или ссылка на него.</em></p>";
    echo "<hr>";
}

echo "</body></html>";
exit;
?>
